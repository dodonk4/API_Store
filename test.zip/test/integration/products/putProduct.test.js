import { app } from '../../../src/app.ts';
import request from 'supertest';
import { getAdminAgent, getNonAuthenticatedAgent } from '../../helpers/getAccessToken.ts';
import { badProductCreate, productUpdate } from '../../fixtures/products.fixture.ts';
import { prisma } from '../../../src/lib/prisma.ts';
import { resetDatabase } from '../../helpers/resetDatabase.ts';

describe('PUT /products/:productId', () => {

    beforeEach(async () => {
        await resetDatabase();
    });

    it('debería devolver 200 al actualizar exitosamente un producto', async () => {
        let productId = 8;

        const agent = await getAdminAgent();
        const response = await agent
            .put(`/products/${productId}`)
            .send(productUpdate);

        expect(response.status).toBe(200);
    })


    it('debería devolver 404 al intentar actualizar un producto inexistente', async () => {
        let productId = 99999;

        const agent = await getAdminAgent();
        const response = await agent
            .put(`/products/${productId}`)
            .send(productUpdate);

        expect(response.status).toBe(404);
    })


    it('debería devolver 400 al intentar actualizar un producto con id invalido', async () => {
        let productId = "abcdef";

        const agent = await getAdminAgent();
        const response = await agent
            .put(`/products/${productId}`)
            .send(productUpdate);

        expect(response.status).toBe(400);
    })

    it('debería devolver 401 al no encontrar un token', async () => {
        let productId = 8;

        const response = await request(app)
            .put(`/products/${productId}`)
            .send(productUpdate);

        expect(response.status).toBe(401);
    })

    it('debería devolver 403 al intentar actualizar un producto siendo USER', async () => {
        let productId = 8;

        const agent = await getNonAuthenticatedAgent();
        const response = await agent
            .put(`/products/${productId}`)
            .send(productUpdate);

        expect(response.status).toBe(403);
    })

    it('debería devolver un error de zod 400 por subir mal los datos a actualizar del producto', async () => {
        const agent = await getAdminAgent();

        const res = await agent
            .post('/products')
            .send(badProductCreate);//El badProductCreate sirve también para la actualización mala

        expect(res.status).toBe(400);

    });

    afterAll(async () => {
        await prisma.$disconnect();
    });
})