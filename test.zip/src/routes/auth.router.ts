import express from 'express';
import { register } from '../controllers/auth/register.controller.ts';
import { logout } from '../controllers/auth/logout.controller.ts';
import { generateAccessTokenForLoggedUser } from '../controllers/auth/generateAccessToken.controller.ts';
import { validateSchema } from '../middlewares/validateSchema.middleware.ts';
import { loginSchema, registerSchema } from '../schemas/auth.schema.ts';
import { login } from '../controllers/auth/login.controller.ts';
import { validateRefreshToken } from '../middlewares/validateRefreshToken.middleware.ts';


const router = express.Router();
/**
 * @swagger
 * /auth/refresh:
 *   post:
 *     summary: Refresh access token.
 *     description: Generates a new access token using a valid refresh token.
 *     tags:
 *       - Authentication
 *
 *     security:
 *       - bearerAuth: []
 *
 *     responses:
 *       200:
 *         description: Access token refreshed successfully.
 *
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
router.post('/refresh', validateRefreshToken, generateAccessTokenForLoggedUser);
/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Register a new user.
 *     description: Creates a new user account.
 *     tags:
 *       - Authentication
 *
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterRequest'
 *
 *     responses:
 *       201:
 *         description: User registered successfully.
 *
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *
 *       409:
 *         $ref: '#/components/responses/Conflict'
 *
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
router.post('/register', validateSchema(registerSchema), register);
/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Log in.
 *     description: Authenticates a user and returns an access token and a refresh token.
 *     tags:
 *       - Authentication
 *
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *
 *     responses:
 *       200:
 *         description: Login successful.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LoginResponse'
 *
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
router.post('/login', validateSchema(loginSchema), login);
/**
 * @swagger
 * /auth/logout:
 *   post:
 *     summary: Log out.
 *     description: Invalidates the current refresh token.
 *     tags:
 *       - Authentication
 *
 *     security:
 *       - bearerAuth: []
 *
 *     responses:
 *       204:
 *         description: Logged out successfully.
 *
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
router.post('/logout', validateRefreshToken, logout);

export default router;