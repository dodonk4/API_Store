
/**
 * Client
**/

import * as runtime from './runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model ordenes
 * 
 */
export type ordenes = $Result.DefaultSelection<Prisma.$ordenesPayload>
/**
 * Model usuarios
 * 
 */
export type usuarios = $Result.DefaultSelection<Prisma.$usuariosPayload>
/**
 * Model productos
 * 
 */
export type productos = $Result.DefaultSelection<Prisma.$productosPayload>
/**
 * Model ordenes_productos
 * 
 */
export type ordenes_productos = $Result.DefaultSelection<Prisma.$ordenes_productosPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Roles: {
  USER: 'USER',
  ADMIN: 'ADMIN'
};

export type Roles = (typeof Roles)[keyof typeof Roles]


export const Estados: {
  CARRITO: 'CARRITO',
  PAGO_PENDIENTE: 'PAGO_PENDIENTE',
  PAGADA: 'PAGADA',
  CANCELADA: 'CANCELADA'
};

export type Estados = (typeof Estados)[keyof typeof Estados]

}

export type Roles = $Enums.Roles

export const Roles: typeof $Enums.Roles

export type Estados = $Enums.Estados

export const Estados: typeof $Enums.Estados

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient({
 *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
 * })
 * // Fetch zero or more Ordenes
 * const ordenes = await prisma.ordenes.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient({
   *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
   * })
   * // Fetch zero or more Ordenes
   * const ordenes = await prisma.ordenes.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.ordenes`: Exposes CRUD operations for the **ordenes** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Ordenes
    * const ordenes = await prisma.ordenes.findMany()
    * ```
    */
  get ordenes(): Prisma.ordenesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.usuarios`: Exposes CRUD operations for the **usuarios** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Usuarios
    * const usuarios = await prisma.usuarios.findMany()
    * ```
    */
  get usuarios(): Prisma.usuariosDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.productos`: Exposes CRUD operations for the **productos** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Productos
    * const productos = await prisma.productos.findMany()
    * ```
    */
  get productos(): Prisma.productosDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.ordenes_productos`: Exposes CRUD operations for the **ordenes_productos** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Ordenes_productos
    * const ordenes_productos = await prisma.ordenes_productos.findMany()
    * ```
    */
  get ordenes_productos(): Prisma.ordenes_productosDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.8.0
   * Query Engine version: 3c6e192761c0362d496ed980de936e2f3cebcd3a
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    ordenes: 'ordenes',
    usuarios: 'usuarios',
    productos: 'productos',
    ordenes_productos: 'ordenes_productos'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "ordenes" | "usuarios" | "productos" | "ordenes_productos"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      ordenes: {
        payload: Prisma.$ordenesPayload<ExtArgs>
        fields: Prisma.ordenesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ordenesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ordenesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>
          }
          findFirst: {
            args: Prisma.ordenesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ordenesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>
          }
          findMany: {
            args: Prisma.ordenesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>[]
          }
          create: {
            args: Prisma.ordenesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>
          }
          createMany: {
            args: Prisma.ordenesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ordenesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>[]
          }
          delete: {
            args: Prisma.ordenesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>
          }
          update: {
            args: Prisma.ordenesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>
          }
          deleteMany: {
            args: Prisma.ordenesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ordenesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ordenesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>[]
          }
          upsert: {
            args: Prisma.ordenesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenesPayload>
          }
          aggregate: {
            args: Prisma.OrdenesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOrdenes>
          }
          groupBy: {
            args: Prisma.ordenesGroupByArgs<ExtArgs>
            result: $Utils.Optional<OrdenesGroupByOutputType>[]
          }
          count: {
            args: Prisma.ordenesCountArgs<ExtArgs>
            result: $Utils.Optional<OrdenesCountAggregateOutputType> | number
          }
        }
      }
      usuarios: {
        payload: Prisma.$usuariosPayload<ExtArgs>
        fields: Prisma.usuariosFieldRefs
        operations: {
          findUnique: {
            args: Prisma.usuariosFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.usuariosFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          findFirst: {
            args: Prisma.usuariosFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.usuariosFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          findMany: {
            args: Prisma.usuariosFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>[]
          }
          create: {
            args: Prisma.usuariosCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          createMany: {
            args: Prisma.usuariosCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.usuariosCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>[]
          }
          delete: {
            args: Prisma.usuariosDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          update: {
            args: Prisma.usuariosUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          deleteMany: {
            args: Prisma.usuariosDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.usuariosUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.usuariosUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>[]
          }
          upsert: {
            args: Prisma.usuariosUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          aggregate: {
            args: Prisma.UsuariosAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUsuarios>
          }
          groupBy: {
            args: Prisma.usuariosGroupByArgs<ExtArgs>
            result: $Utils.Optional<UsuariosGroupByOutputType>[]
          }
          count: {
            args: Prisma.usuariosCountArgs<ExtArgs>
            result: $Utils.Optional<UsuariosCountAggregateOutputType> | number
          }
        }
      }
      productos: {
        payload: Prisma.$productosPayload<ExtArgs>
        fields: Prisma.productosFieldRefs
        operations: {
          findUnique: {
            args: Prisma.productosFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.productosFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>
          }
          findFirst: {
            args: Prisma.productosFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.productosFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>
          }
          findMany: {
            args: Prisma.productosFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>[]
          }
          create: {
            args: Prisma.productosCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>
          }
          createMany: {
            args: Prisma.productosCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.productosCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>[]
          }
          delete: {
            args: Prisma.productosDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>
          }
          update: {
            args: Prisma.productosUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>
          }
          deleteMany: {
            args: Prisma.productosDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.productosUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.productosUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>[]
          }
          upsert: {
            args: Prisma.productosUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$productosPayload>
          }
          aggregate: {
            args: Prisma.ProductosAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateProductos>
          }
          groupBy: {
            args: Prisma.productosGroupByArgs<ExtArgs>
            result: $Utils.Optional<ProductosGroupByOutputType>[]
          }
          count: {
            args: Prisma.productosCountArgs<ExtArgs>
            result: $Utils.Optional<ProductosCountAggregateOutputType> | number
          }
        }
      }
      ordenes_productos: {
        payload: Prisma.$ordenes_productosPayload<ExtArgs>
        fields: Prisma.ordenes_productosFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ordenes_productosFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ordenes_productosFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>
          }
          findFirst: {
            args: Prisma.ordenes_productosFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ordenes_productosFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>
          }
          findMany: {
            args: Prisma.ordenes_productosFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>[]
          }
          create: {
            args: Prisma.ordenes_productosCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>
          }
          createMany: {
            args: Prisma.ordenes_productosCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ordenes_productosCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>[]
          }
          delete: {
            args: Prisma.ordenes_productosDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>
          }
          update: {
            args: Prisma.ordenes_productosUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>
          }
          deleteMany: {
            args: Prisma.ordenes_productosDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ordenes_productosUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ordenes_productosUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>[]
          }
          upsert: {
            args: Prisma.ordenes_productosUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ordenes_productosPayload>
          }
          aggregate: {
            args: Prisma.Ordenes_productosAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOrdenes_productos>
          }
          groupBy: {
            args: Prisma.ordenes_productosGroupByArgs<ExtArgs>
            result: $Utils.Optional<Ordenes_productosGroupByOutputType>[]
          }
          count: {
            args: Prisma.ordenes_productosCountArgs<ExtArgs>
            result: $Utils.Optional<Ordenes_productosCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    ordenes?: ordenesOmit
    usuarios?: usuariosOmit
    productos?: productosOmit
    ordenes_productos?: ordenes_productosOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type OrdenesCountOutputType
   */

  export type OrdenesCountOutputType = {
    ordenesProductos: number
  }

  export type OrdenesCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ordenesProductos?: boolean | OrdenesCountOutputTypeCountOrdenesProductosArgs
  }

  // Custom InputTypes
  /**
   * OrdenesCountOutputType without action
   */
  export type OrdenesCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OrdenesCountOutputType
     */
    select?: OrdenesCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * OrdenesCountOutputType without action
   */
  export type OrdenesCountOutputTypeCountOrdenesProductosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ordenes_productosWhereInput
  }


  /**
   * Count Type UsuariosCountOutputType
   */

  export type UsuariosCountOutputType = {
    ordenes: number
  }

  export type UsuariosCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ordenes?: boolean | UsuariosCountOutputTypeCountOrdenesArgs
  }

  // Custom InputTypes
  /**
   * UsuariosCountOutputType without action
   */
  export type UsuariosCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsuariosCountOutputType
     */
    select?: UsuariosCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UsuariosCountOutputType without action
   */
  export type UsuariosCountOutputTypeCountOrdenesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ordenesWhereInput
  }


  /**
   * Count Type ProductosCountOutputType
   */

  export type ProductosCountOutputType = {
    ordenesProductos: number
  }

  export type ProductosCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ordenesProductos?: boolean | ProductosCountOutputTypeCountOrdenesProductosArgs
  }

  // Custom InputTypes
  /**
   * ProductosCountOutputType without action
   */
  export type ProductosCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductosCountOutputType
     */
    select?: ProductosCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ProductosCountOutputType without action
   */
  export type ProductosCountOutputTypeCountOrdenesProductosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ordenes_productosWhereInput
  }


  /**
   * Models
   */

  /**
   * Model ordenes
   */

  export type AggregateOrdenes = {
    _count: OrdenesCountAggregateOutputType | null
    _avg: OrdenesAvgAggregateOutputType | null
    _sum: OrdenesSumAggregateOutputType | null
    _min: OrdenesMinAggregateOutputType | null
    _max: OrdenesMaxAggregateOutputType | null
  }

  export type OrdenesAvgAggregateOutputType = {
    id: number | null
    usuarioId: number | null
  }

  export type OrdenesSumAggregateOutputType = {
    id: number | null
    usuarioId: number | null
  }

  export type OrdenesMinAggregateOutputType = {
    id: number | null
    usuarioId: number | null
    fecha: Date | null
    estado: $Enums.Estados | null
    createdAt: Date | null
  }

  export type OrdenesMaxAggregateOutputType = {
    id: number | null
    usuarioId: number | null
    fecha: Date | null
    estado: $Enums.Estados | null
    createdAt: Date | null
  }

  export type OrdenesCountAggregateOutputType = {
    id: number
    usuarioId: number
    fecha: number
    estado: number
    createdAt: number
    _all: number
  }


  export type OrdenesAvgAggregateInputType = {
    id?: true
    usuarioId?: true
  }

  export type OrdenesSumAggregateInputType = {
    id?: true
    usuarioId?: true
  }

  export type OrdenesMinAggregateInputType = {
    id?: true
    usuarioId?: true
    fecha?: true
    estado?: true
    createdAt?: true
  }

  export type OrdenesMaxAggregateInputType = {
    id?: true
    usuarioId?: true
    fecha?: true
    estado?: true
    createdAt?: true
  }

  export type OrdenesCountAggregateInputType = {
    id?: true
    usuarioId?: true
    fecha?: true
    estado?: true
    createdAt?: true
    _all?: true
  }

  export type OrdenesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ordenes to aggregate.
     */
    where?: ordenesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes to fetch.
     */
    orderBy?: ordenesOrderByWithRelationInput | ordenesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ordenesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ordenes
    **/
    _count?: true | OrdenesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: OrdenesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: OrdenesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: OrdenesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: OrdenesMaxAggregateInputType
  }

  export type GetOrdenesAggregateType<T extends OrdenesAggregateArgs> = {
        [P in keyof T & keyof AggregateOrdenes]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOrdenes[P]>
      : GetScalarType<T[P], AggregateOrdenes[P]>
  }




  export type ordenesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ordenesWhereInput
    orderBy?: ordenesOrderByWithAggregationInput | ordenesOrderByWithAggregationInput[]
    by: OrdenesScalarFieldEnum[] | OrdenesScalarFieldEnum
    having?: ordenesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: OrdenesCountAggregateInputType | true
    _avg?: OrdenesAvgAggregateInputType
    _sum?: OrdenesSumAggregateInputType
    _min?: OrdenesMinAggregateInputType
    _max?: OrdenesMaxAggregateInputType
  }

  export type OrdenesGroupByOutputType = {
    id: number
    usuarioId: number
    fecha: Date
    estado: $Enums.Estados
    createdAt: Date
    _count: OrdenesCountAggregateOutputType | null
    _avg: OrdenesAvgAggregateOutputType | null
    _sum: OrdenesSumAggregateOutputType | null
    _min: OrdenesMinAggregateOutputType | null
    _max: OrdenesMaxAggregateOutputType | null
  }

  type GetOrdenesGroupByPayload<T extends ordenesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<OrdenesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof OrdenesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], OrdenesGroupByOutputType[P]>
            : GetScalarType<T[P], OrdenesGroupByOutputType[P]>
        }
      >
    >


  export type ordenesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    usuarioId?: boolean
    fecha?: boolean
    estado?: boolean
    createdAt?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    ordenesProductos?: boolean | ordenes$ordenesProductosArgs<ExtArgs>
    _count?: boolean | OrdenesCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ordenes"]>

  export type ordenesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    usuarioId?: boolean
    fecha?: boolean
    estado?: boolean
    createdAt?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ordenes"]>

  export type ordenesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    usuarioId?: boolean
    fecha?: boolean
    estado?: boolean
    createdAt?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ordenes"]>

  export type ordenesSelectScalar = {
    id?: boolean
    usuarioId?: boolean
    fecha?: boolean
    estado?: boolean
    createdAt?: boolean
  }

  export type ordenesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "usuarioId" | "fecha" | "estado" | "createdAt", ExtArgs["result"]["ordenes"]>
  export type ordenesInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    ordenesProductos?: boolean | ordenes$ordenesProductosArgs<ExtArgs>
    _count?: boolean | OrdenesCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type ordenesIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
  }
  export type ordenesIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
  }

  export type $ordenesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ordenes"
    objects: {
      usuarios: Prisma.$usuariosPayload<ExtArgs>
      ordenesProductos: Prisma.$ordenes_productosPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      usuarioId: number
      fecha: Date
      estado: $Enums.Estados
      createdAt: Date
    }, ExtArgs["result"]["ordenes"]>
    composites: {}
  }

  type ordenesGetPayload<S extends boolean | null | undefined | ordenesDefaultArgs> = $Result.GetResult<Prisma.$ordenesPayload, S>

  type ordenesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ordenesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: OrdenesCountAggregateInputType | true
    }

  export interface ordenesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ordenes'], meta: { name: 'ordenes' } }
    /**
     * Find zero or one Ordenes that matches the filter.
     * @param {ordenesFindUniqueArgs} args - Arguments to find a Ordenes
     * @example
     * // Get one Ordenes
     * const ordenes = await prisma.ordenes.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ordenesFindUniqueArgs>(args: SelectSubset<T, ordenesFindUniqueArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Ordenes that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ordenesFindUniqueOrThrowArgs} args - Arguments to find a Ordenes
     * @example
     * // Get one Ordenes
     * const ordenes = await prisma.ordenes.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ordenesFindUniqueOrThrowArgs>(args: SelectSubset<T, ordenesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Ordenes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenesFindFirstArgs} args - Arguments to find a Ordenes
     * @example
     * // Get one Ordenes
     * const ordenes = await prisma.ordenes.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ordenesFindFirstArgs>(args?: SelectSubset<T, ordenesFindFirstArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Ordenes that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenesFindFirstOrThrowArgs} args - Arguments to find a Ordenes
     * @example
     * // Get one Ordenes
     * const ordenes = await prisma.ordenes.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ordenesFindFirstOrThrowArgs>(args?: SelectSubset<T, ordenesFindFirstOrThrowArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Ordenes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Ordenes
     * const ordenes = await prisma.ordenes.findMany()
     * 
     * // Get first 10 Ordenes
     * const ordenes = await prisma.ordenes.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const ordenesWithIdOnly = await prisma.ordenes.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ordenesFindManyArgs>(args?: SelectSubset<T, ordenesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Ordenes.
     * @param {ordenesCreateArgs} args - Arguments to create a Ordenes.
     * @example
     * // Create one Ordenes
     * const Ordenes = await prisma.ordenes.create({
     *   data: {
     *     // ... data to create a Ordenes
     *   }
     * })
     * 
     */
    create<T extends ordenesCreateArgs>(args: SelectSubset<T, ordenesCreateArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Ordenes.
     * @param {ordenesCreateManyArgs} args - Arguments to create many Ordenes.
     * @example
     * // Create many Ordenes
     * const ordenes = await prisma.ordenes.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ordenesCreateManyArgs>(args?: SelectSubset<T, ordenesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Ordenes and returns the data saved in the database.
     * @param {ordenesCreateManyAndReturnArgs} args - Arguments to create many Ordenes.
     * @example
     * // Create many Ordenes
     * const ordenes = await prisma.ordenes.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Ordenes and only return the `id`
     * const ordenesWithIdOnly = await prisma.ordenes.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ordenesCreateManyAndReturnArgs>(args?: SelectSubset<T, ordenesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Ordenes.
     * @param {ordenesDeleteArgs} args - Arguments to delete one Ordenes.
     * @example
     * // Delete one Ordenes
     * const Ordenes = await prisma.ordenes.delete({
     *   where: {
     *     // ... filter to delete one Ordenes
     *   }
     * })
     * 
     */
    delete<T extends ordenesDeleteArgs>(args: SelectSubset<T, ordenesDeleteArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Ordenes.
     * @param {ordenesUpdateArgs} args - Arguments to update one Ordenes.
     * @example
     * // Update one Ordenes
     * const ordenes = await prisma.ordenes.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ordenesUpdateArgs>(args: SelectSubset<T, ordenesUpdateArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Ordenes.
     * @param {ordenesDeleteManyArgs} args - Arguments to filter Ordenes to delete.
     * @example
     * // Delete a few Ordenes
     * const { count } = await prisma.ordenes.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ordenesDeleteManyArgs>(args?: SelectSubset<T, ordenesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Ordenes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Ordenes
     * const ordenes = await prisma.ordenes.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ordenesUpdateManyArgs>(args: SelectSubset<T, ordenesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Ordenes and returns the data updated in the database.
     * @param {ordenesUpdateManyAndReturnArgs} args - Arguments to update many Ordenes.
     * @example
     * // Update many Ordenes
     * const ordenes = await prisma.ordenes.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Ordenes and only return the `id`
     * const ordenesWithIdOnly = await prisma.ordenes.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ordenesUpdateManyAndReturnArgs>(args: SelectSubset<T, ordenesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Ordenes.
     * @param {ordenesUpsertArgs} args - Arguments to update or create a Ordenes.
     * @example
     * // Update or create a Ordenes
     * const ordenes = await prisma.ordenes.upsert({
     *   create: {
     *     // ... data to create a Ordenes
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Ordenes we want to update
     *   }
     * })
     */
    upsert<T extends ordenesUpsertArgs>(args: SelectSubset<T, ordenesUpsertArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Ordenes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenesCountArgs} args - Arguments to filter Ordenes to count.
     * @example
     * // Count the number of Ordenes
     * const count = await prisma.ordenes.count({
     *   where: {
     *     // ... the filter for the Ordenes we want to count
     *   }
     * })
    **/
    count<T extends ordenesCountArgs>(
      args?: Subset<T, ordenesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], OrdenesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Ordenes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrdenesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OrdenesAggregateArgs>(args: Subset<T, OrdenesAggregateArgs>): Prisma.PrismaPromise<GetOrdenesAggregateType<T>>

    /**
     * Group by Ordenes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ordenesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ordenesGroupByArgs['orderBy'] }
        : { orderBy?: ordenesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ordenesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOrdenesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ordenes model
   */
  readonly fields: ordenesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ordenes.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ordenesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    usuarios<T extends usuariosDefaultArgs<ExtArgs> = {}>(args?: Subset<T, usuariosDefaultArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    ordenesProductos<T extends ordenes$ordenesProductosArgs<ExtArgs> = {}>(args?: Subset<T, ordenes$ordenesProductosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ordenes model
   */
  interface ordenesFieldRefs {
    readonly id: FieldRef<"ordenes", 'Int'>
    readonly usuarioId: FieldRef<"ordenes", 'Int'>
    readonly fecha: FieldRef<"ordenes", 'DateTime'>
    readonly estado: FieldRef<"ordenes", 'Estados'>
    readonly createdAt: FieldRef<"ordenes", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * ordenes findUnique
   */
  export type ordenesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * Filter, which ordenes to fetch.
     */
    where: ordenesWhereUniqueInput
  }

  /**
   * ordenes findUniqueOrThrow
   */
  export type ordenesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * Filter, which ordenes to fetch.
     */
    where: ordenesWhereUniqueInput
  }

  /**
   * ordenes findFirst
   */
  export type ordenesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * Filter, which ordenes to fetch.
     */
    where?: ordenesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes to fetch.
     */
    orderBy?: ordenesOrderByWithRelationInput | ordenesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ordenes.
     */
    cursor?: ordenesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ordenes.
     */
    distinct?: OrdenesScalarFieldEnum | OrdenesScalarFieldEnum[]
  }

  /**
   * ordenes findFirstOrThrow
   */
  export type ordenesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * Filter, which ordenes to fetch.
     */
    where?: ordenesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes to fetch.
     */
    orderBy?: ordenesOrderByWithRelationInput | ordenesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ordenes.
     */
    cursor?: ordenesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ordenes.
     */
    distinct?: OrdenesScalarFieldEnum | OrdenesScalarFieldEnum[]
  }

  /**
   * ordenes findMany
   */
  export type ordenesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * Filter, which ordenes to fetch.
     */
    where?: ordenesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes to fetch.
     */
    orderBy?: ordenesOrderByWithRelationInput | ordenesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ordenes.
     */
    cursor?: ordenesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ordenes.
     */
    distinct?: OrdenesScalarFieldEnum | OrdenesScalarFieldEnum[]
  }

  /**
   * ordenes create
   */
  export type ordenesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * The data needed to create a ordenes.
     */
    data: XOR<ordenesCreateInput, ordenesUncheckedCreateInput>
  }

  /**
   * ordenes createMany
   */
  export type ordenesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ordenes.
     */
    data: ordenesCreateManyInput | ordenesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ordenes createManyAndReturn
   */
  export type ordenesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * The data used to create many ordenes.
     */
    data: ordenesCreateManyInput | ordenesCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ordenes update
   */
  export type ordenesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * The data needed to update a ordenes.
     */
    data: XOR<ordenesUpdateInput, ordenesUncheckedUpdateInput>
    /**
     * Choose, which ordenes to update.
     */
    where: ordenesWhereUniqueInput
  }

  /**
   * ordenes updateMany
   */
  export type ordenesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ordenes.
     */
    data: XOR<ordenesUpdateManyMutationInput, ordenesUncheckedUpdateManyInput>
    /**
     * Filter which ordenes to update
     */
    where?: ordenesWhereInput
    /**
     * Limit how many ordenes to update.
     */
    limit?: number
  }

  /**
   * ordenes updateManyAndReturn
   */
  export type ordenesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * The data used to update ordenes.
     */
    data: XOR<ordenesUpdateManyMutationInput, ordenesUncheckedUpdateManyInput>
    /**
     * Filter which ordenes to update
     */
    where?: ordenesWhereInput
    /**
     * Limit how many ordenes to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ordenes upsert
   */
  export type ordenesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * The filter to search for the ordenes to update in case it exists.
     */
    where: ordenesWhereUniqueInput
    /**
     * In case the ordenes found by the `where` argument doesn't exist, create a new ordenes with this data.
     */
    create: XOR<ordenesCreateInput, ordenesUncheckedCreateInput>
    /**
     * In case the ordenes was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ordenesUpdateInput, ordenesUncheckedUpdateInput>
  }

  /**
   * ordenes delete
   */
  export type ordenesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    /**
     * Filter which ordenes to delete.
     */
    where: ordenesWhereUniqueInput
  }

  /**
   * ordenes deleteMany
   */
  export type ordenesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ordenes to delete
     */
    where?: ordenesWhereInput
    /**
     * Limit how many ordenes to delete.
     */
    limit?: number
  }

  /**
   * ordenes.ordenesProductos
   */
  export type ordenes$ordenesProductosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    where?: ordenes_productosWhereInput
    orderBy?: ordenes_productosOrderByWithRelationInput | ordenes_productosOrderByWithRelationInput[]
    cursor?: ordenes_productosWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Ordenes_productosScalarFieldEnum | Ordenes_productosScalarFieldEnum[]
  }

  /**
   * ordenes without action
   */
  export type ordenesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
  }


  /**
   * Model usuarios
   */

  export type AggregateUsuarios = {
    _count: UsuariosCountAggregateOutputType | null
    _avg: UsuariosAvgAggregateOutputType | null
    _sum: UsuariosSumAggregateOutputType | null
    _min: UsuariosMinAggregateOutputType | null
    _max: UsuariosMaxAggregateOutputType | null
  }

  export type UsuariosAvgAggregateOutputType = {
    id: number | null
  }

  export type UsuariosSumAggregateOutputType = {
    id: number | null
  }

  export type UsuariosMinAggregateOutputType = {
    id: number | null
    nombre: string | null
    email: string | null
    rol: $Enums.Roles | null
    password: string | null
    refreshToken: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UsuariosMaxAggregateOutputType = {
    id: number | null
    nombre: string | null
    email: string | null
    rol: $Enums.Roles | null
    password: string | null
    refreshToken: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UsuariosCountAggregateOutputType = {
    id: number
    nombre: number
    email: number
    rol: number
    password: number
    refreshToken: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UsuariosAvgAggregateInputType = {
    id?: true
  }

  export type UsuariosSumAggregateInputType = {
    id?: true
  }

  export type UsuariosMinAggregateInputType = {
    id?: true
    nombre?: true
    email?: true
    rol?: true
    password?: true
    refreshToken?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UsuariosMaxAggregateInputType = {
    id?: true
    nombre?: true
    email?: true
    rol?: true
    password?: true
    refreshToken?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UsuariosCountAggregateInputType = {
    id?: true
    nombre?: true
    email?: true
    rol?: true
    password?: true
    refreshToken?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UsuariosAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usuarios to aggregate.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned usuarios
    **/
    _count?: true | UsuariosCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UsuariosAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UsuariosSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsuariosMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsuariosMaxAggregateInputType
  }

  export type GetUsuariosAggregateType<T extends UsuariosAggregateArgs> = {
        [P in keyof T & keyof AggregateUsuarios]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsuarios[P]>
      : GetScalarType<T[P], AggregateUsuarios[P]>
  }




  export type usuariosGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usuariosWhereInput
    orderBy?: usuariosOrderByWithAggregationInput | usuariosOrderByWithAggregationInput[]
    by: UsuariosScalarFieldEnum[] | UsuariosScalarFieldEnum
    having?: usuariosScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsuariosCountAggregateInputType | true
    _avg?: UsuariosAvgAggregateInputType
    _sum?: UsuariosSumAggregateInputType
    _min?: UsuariosMinAggregateInputType
    _max?: UsuariosMaxAggregateInputType
  }

  export type UsuariosGroupByOutputType = {
    id: number
    nombre: string
    email: string
    rol: $Enums.Roles
    password: string
    refreshToken: string | null
    createdAt: Date
    updatedAt: Date
    _count: UsuariosCountAggregateOutputType | null
    _avg: UsuariosAvgAggregateOutputType | null
    _sum: UsuariosSumAggregateOutputType | null
    _min: UsuariosMinAggregateOutputType | null
    _max: UsuariosMaxAggregateOutputType | null
  }

  type GetUsuariosGroupByPayload<T extends usuariosGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UsuariosGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsuariosGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsuariosGroupByOutputType[P]>
            : GetScalarType<T[P], UsuariosGroupByOutputType[P]>
        }
      >
    >


  export type usuariosSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    email?: boolean
    rol?: boolean
    password?: boolean
    refreshToken?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    ordenes?: boolean | usuarios$ordenesArgs<ExtArgs>
    _count?: boolean | UsuariosCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["usuarios"]>

  export type usuariosSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    email?: boolean
    rol?: boolean
    password?: boolean
    refreshToken?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["usuarios"]>

  export type usuariosSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    email?: boolean
    rol?: boolean
    password?: boolean
    refreshToken?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["usuarios"]>

  export type usuariosSelectScalar = {
    id?: boolean
    nombre?: boolean
    email?: boolean
    rol?: boolean
    password?: boolean
    refreshToken?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type usuariosOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "nombre" | "email" | "rol" | "password" | "refreshToken" | "createdAt" | "updatedAt", ExtArgs["result"]["usuarios"]>
  export type usuariosInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ordenes?: boolean | usuarios$ordenesArgs<ExtArgs>
    _count?: boolean | UsuariosCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type usuariosIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type usuariosIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $usuariosPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "usuarios"
    objects: {
      ordenes: Prisma.$ordenesPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      nombre: string
      email: string
      rol: $Enums.Roles
      password: string
      refreshToken: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["usuarios"]>
    composites: {}
  }

  type usuariosGetPayload<S extends boolean | null | undefined | usuariosDefaultArgs> = $Result.GetResult<Prisma.$usuariosPayload, S>

  type usuariosCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<usuariosFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UsuariosCountAggregateInputType | true
    }

  export interface usuariosDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['usuarios'], meta: { name: 'usuarios' } }
    /**
     * Find zero or one Usuarios that matches the filter.
     * @param {usuariosFindUniqueArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends usuariosFindUniqueArgs>(args: SelectSubset<T, usuariosFindUniqueArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Usuarios that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {usuariosFindUniqueOrThrowArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends usuariosFindUniqueOrThrowArgs>(args: SelectSubset<T, usuariosFindUniqueOrThrowArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usuarios that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosFindFirstArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends usuariosFindFirstArgs>(args?: SelectSubset<T, usuariosFindFirstArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usuarios that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosFindFirstOrThrowArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends usuariosFindFirstOrThrowArgs>(args?: SelectSubset<T, usuariosFindFirstOrThrowArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Usuarios that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Usuarios
     * const usuarios = await prisma.usuarios.findMany()
     * 
     * // Get first 10 Usuarios
     * const usuarios = await prisma.usuarios.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const usuariosWithIdOnly = await prisma.usuarios.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends usuariosFindManyArgs>(args?: SelectSubset<T, usuariosFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Usuarios.
     * @param {usuariosCreateArgs} args - Arguments to create a Usuarios.
     * @example
     * // Create one Usuarios
     * const Usuarios = await prisma.usuarios.create({
     *   data: {
     *     // ... data to create a Usuarios
     *   }
     * })
     * 
     */
    create<T extends usuariosCreateArgs>(args: SelectSubset<T, usuariosCreateArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Usuarios.
     * @param {usuariosCreateManyArgs} args - Arguments to create many Usuarios.
     * @example
     * // Create many Usuarios
     * const usuarios = await prisma.usuarios.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends usuariosCreateManyArgs>(args?: SelectSubset<T, usuariosCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Usuarios and returns the data saved in the database.
     * @param {usuariosCreateManyAndReturnArgs} args - Arguments to create many Usuarios.
     * @example
     * // Create many Usuarios
     * const usuarios = await prisma.usuarios.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Usuarios and only return the `id`
     * const usuariosWithIdOnly = await prisma.usuarios.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends usuariosCreateManyAndReturnArgs>(args?: SelectSubset<T, usuariosCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Usuarios.
     * @param {usuariosDeleteArgs} args - Arguments to delete one Usuarios.
     * @example
     * // Delete one Usuarios
     * const Usuarios = await prisma.usuarios.delete({
     *   where: {
     *     // ... filter to delete one Usuarios
     *   }
     * })
     * 
     */
    delete<T extends usuariosDeleteArgs>(args: SelectSubset<T, usuariosDeleteArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Usuarios.
     * @param {usuariosUpdateArgs} args - Arguments to update one Usuarios.
     * @example
     * // Update one Usuarios
     * const usuarios = await prisma.usuarios.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends usuariosUpdateArgs>(args: SelectSubset<T, usuariosUpdateArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Usuarios.
     * @param {usuariosDeleteManyArgs} args - Arguments to filter Usuarios to delete.
     * @example
     * // Delete a few Usuarios
     * const { count } = await prisma.usuarios.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends usuariosDeleteManyArgs>(args?: SelectSubset<T, usuariosDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Usuarios
     * const usuarios = await prisma.usuarios.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends usuariosUpdateManyArgs>(args: SelectSubset<T, usuariosUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Usuarios and returns the data updated in the database.
     * @param {usuariosUpdateManyAndReturnArgs} args - Arguments to update many Usuarios.
     * @example
     * // Update many Usuarios
     * const usuarios = await prisma.usuarios.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Usuarios and only return the `id`
     * const usuariosWithIdOnly = await prisma.usuarios.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends usuariosUpdateManyAndReturnArgs>(args: SelectSubset<T, usuariosUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Usuarios.
     * @param {usuariosUpsertArgs} args - Arguments to update or create a Usuarios.
     * @example
     * // Update or create a Usuarios
     * const usuarios = await prisma.usuarios.upsert({
     *   create: {
     *     // ... data to create a Usuarios
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Usuarios we want to update
     *   }
     * })
     */
    upsert<T extends usuariosUpsertArgs>(args: SelectSubset<T, usuariosUpsertArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosCountArgs} args - Arguments to filter Usuarios to count.
     * @example
     * // Count the number of Usuarios
     * const count = await prisma.usuarios.count({
     *   where: {
     *     // ... the filter for the Usuarios we want to count
     *   }
     * })
    **/
    count<T extends usuariosCountArgs>(
      args?: Subset<T, usuariosCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsuariosCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuariosAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsuariosAggregateArgs>(args: Subset<T, UsuariosAggregateArgs>): Prisma.PrismaPromise<GetUsuariosAggregateType<T>>

    /**
     * Group by Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends usuariosGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: usuariosGroupByArgs['orderBy'] }
        : { orderBy?: usuariosGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, usuariosGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsuariosGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the usuarios model
   */
  readonly fields: usuariosFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for usuarios.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__usuariosClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    ordenes<T extends usuarios$ordenesArgs<ExtArgs> = {}>(args?: Subset<T, usuarios$ordenesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the usuarios model
   */
  interface usuariosFieldRefs {
    readonly id: FieldRef<"usuarios", 'Int'>
    readonly nombre: FieldRef<"usuarios", 'String'>
    readonly email: FieldRef<"usuarios", 'String'>
    readonly rol: FieldRef<"usuarios", 'Roles'>
    readonly password: FieldRef<"usuarios", 'String'>
    readonly refreshToken: FieldRef<"usuarios", 'String'>
    readonly createdAt: FieldRef<"usuarios", 'DateTime'>
    readonly updatedAt: FieldRef<"usuarios", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * usuarios findUnique
   */
  export type usuariosFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios findUniqueOrThrow
   */
  export type usuariosFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios findFirst
   */
  export type usuariosFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usuarios.
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usuarios.
     */
    distinct?: UsuariosScalarFieldEnum | UsuariosScalarFieldEnum[]
  }

  /**
   * usuarios findFirstOrThrow
   */
  export type usuariosFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usuarios.
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usuarios.
     */
    distinct?: UsuariosScalarFieldEnum | UsuariosScalarFieldEnum[]
  }

  /**
   * usuarios findMany
   */
  export type usuariosFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing usuarios.
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usuarios.
     */
    distinct?: UsuariosScalarFieldEnum | UsuariosScalarFieldEnum[]
  }

  /**
   * usuarios create
   */
  export type usuariosCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * The data needed to create a usuarios.
     */
    data: XOR<usuariosCreateInput, usuariosUncheckedCreateInput>
  }

  /**
   * usuarios createMany
   */
  export type usuariosCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many usuarios.
     */
    data: usuariosCreateManyInput | usuariosCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * usuarios createManyAndReturn
   */
  export type usuariosCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * The data used to create many usuarios.
     */
    data: usuariosCreateManyInput | usuariosCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * usuarios update
   */
  export type usuariosUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * The data needed to update a usuarios.
     */
    data: XOR<usuariosUpdateInput, usuariosUncheckedUpdateInput>
    /**
     * Choose, which usuarios to update.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios updateMany
   */
  export type usuariosUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update usuarios.
     */
    data: XOR<usuariosUpdateManyMutationInput, usuariosUncheckedUpdateManyInput>
    /**
     * Filter which usuarios to update
     */
    where?: usuariosWhereInput
    /**
     * Limit how many usuarios to update.
     */
    limit?: number
  }

  /**
   * usuarios updateManyAndReturn
   */
  export type usuariosUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * The data used to update usuarios.
     */
    data: XOR<usuariosUpdateManyMutationInput, usuariosUncheckedUpdateManyInput>
    /**
     * Filter which usuarios to update
     */
    where?: usuariosWhereInput
    /**
     * Limit how many usuarios to update.
     */
    limit?: number
  }

  /**
   * usuarios upsert
   */
  export type usuariosUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * The filter to search for the usuarios to update in case it exists.
     */
    where: usuariosWhereUniqueInput
    /**
     * In case the usuarios found by the `where` argument doesn't exist, create a new usuarios with this data.
     */
    create: XOR<usuariosCreateInput, usuariosUncheckedCreateInput>
    /**
     * In case the usuarios was found with the provided `where` argument, update it with this data.
     */
    update: XOR<usuariosUpdateInput, usuariosUncheckedUpdateInput>
  }

  /**
   * usuarios delete
   */
  export type usuariosDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter which usuarios to delete.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios deleteMany
   */
  export type usuariosDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usuarios to delete
     */
    where?: usuariosWhereInput
    /**
     * Limit how many usuarios to delete.
     */
    limit?: number
  }

  /**
   * usuarios.ordenes
   */
  export type usuarios$ordenesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes
     */
    select?: ordenesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes
     */
    omit?: ordenesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenesInclude<ExtArgs> | null
    where?: ordenesWhereInput
    orderBy?: ordenesOrderByWithRelationInput | ordenesOrderByWithRelationInput[]
    cursor?: ordenesWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrdenesScalarFieldEnum | OrdenesScalarFieldEnum[]
  }

  /**
   * usuarios without action
   */
  export type usuariosDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
  }


  /**
   * Model productos
   */

  export type AggregateProductos = {
    _count: ProductosCountAggregateOutputType | null
    _avg: ProductosAvgAggregateOutputType | null
    _sum: ProductosSumAggregateOutputType | null
    _min: ProductosMinAggregateOutputType | null
    _max: ProductosMaxAggregateOutputType | null
  }

  export type ProductosAvgAggregateOutputType = {
    id: number | null
    stock: number | null
    precio: Decimal | null
  }

  export type ProductosSumAggregateOutputType = {
    id: number | null
    stock: number | null
    precio: Decimal | null
  }

  export type ProductosMinAggregateOutputType = {
    id: number | null
    nombre: string | null
    descripcion: string | null
    categoria: string | null
    stock: number | null
    precio: Decimal | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ProductosMaxAggregateOutputType = {
    id: number | null
    nombre: string | null
    descripcion: string | null
    categoria: string | null
    stock: number | null
    precio: Decimal | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ProductosCountAggregateOutputType = {
    id: number
    nombre: number
    descripcion: number
    categoria: number
    stock: number
    precio: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type ProductosAvgAggregateInputType = {
    id?: true
    stock?: true
    precio?: true
  }

  export type ProductosSumAggregateInputType = {
    id?: true
    stock?: true
    precio?: true
  }

  export type ProductosMinAggregateInputType = {
    id?: true
    nombre?: true
    descripcion?: true
    categoria?: true
    stock?: true
    precio?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ProductosMaxAggregateInputType = {
    id?: true
    nombre?: true
    descripcion?: true
    categoria?: true
    stock?: true
    precio?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ProductosCountAggregateInputType = {
    id?: true
    nombre?: true
    descripcion?: true
    categoria?: true
    stock?: true
    precio?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type ProductosAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which productos to aggregate.
     */
    where?: productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of productos to fetch.
     */
    orderBy?: productosOrderByWithRelationInput | productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned productos
    **/
    _count?: true | ProductosCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ProductosAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ProductosSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProductosMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProductosMaxAggregateInputType
  }

  export type GetProductosAggregateType<T extends ProductosAggregateArgs> = {
        [P in keyof T & keyof AggregateProductos]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProductos[P]>
      : GetScalarType<T[P], AggregateProductos[P]>
  }




  export type productosGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: productosWhereInput
    orderBy?: productosOrderByWithAggregationInput | productosOrderByWithAggregationInput[]
    by: ProductosScalarFieldEnum[] | ProductosScalarFieldEnum
    having?: productosScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProductosCountAggregateInputType | true
    _avg?: ProductosAvgAggregateInputType
    _sum?: ProductosSumAggregateInputType
    _min?: ProductosMinAggregateInputType
    _max?: ProductosMaxAggregateInputType
  }

  export type ProductosGroupByOutputType = {
    id: number
    nombre: string
    descripcion: string | null
    categoria: string
    stock: number
    precio: Decimal
    createdAt: Date
    updatedAt: Date
    _count: ProductosCountAggregateOutputType | null
    _avg: ProductosAvgAggregateOutputType | null
    _sum: ProductosSumAggregateOutputType | null
    _min: ProductosMinAggregateOutputType | null
    _max: ProductosMaxAggregateOutputType | null
  }

  type GetProductosGroupByPayload<T extends productosGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProductosGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProductosGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProductosGroupByOutputType[P]>
            : GetScalarType<T[P], ProductosGroupByOutputType[P]>
        }
      >
    >


  export type productosSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    descripcion?: boolean
    categoria?: boolean
    stock?: boolean
    precio?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    ordenesProductos?: boolean | productos$ordenesProductosArgs<ExtArgs>
    _count?: boolean | ProductosCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["productos"]>

  export type productosSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    descripcion?: boolean
    categoria?: boolean
    stock?: boolean
    precio?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["productos"]>

  export type productosSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    descripcion?: boolean
    categoria?: boolean
    stock?: boolean
    precio?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["productos"]>

  export type productosSelectScalar = {
    id?: boolean
    nombre?: boolean
    descripcion?: boolean
    categoria?: boolean
    stock?: boolean
    precio?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type productosOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "nombre" | "descripcion" | "categoria" | "stock" | "precio" | "createdAt" | "updatedAt", ExtArgs["result"]["productos"]>
  export type productosInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    ordenesProductos?: boolean | productos$ordenesProductosArgs<ExtArgs>
    _count?: boolean | ProductosCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type productosIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type productosIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $productosPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "productos"
    objects: {
      ordenesProductos: Prisma.$ordenes_productosPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      nombre: string
      descripcion: string | null
      categoria: string
      stock: number
      precio: Prisma.Decimal
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["productos"]>
    composites: {}
  }

  type productosGetPayload<S extends boolean | null | undefined | productosDefaultArgs> = $Result.GetResult<Prisma.$productosPayload, S>

  type productosCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<productosFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ProductosCountAggregateInputType | true
    }

  export interface productosDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['productos'], meta: { name: 'productos' } }
    /**
     * Find zero or one Productos that matches the filter.
     * @param {productosFindUniqueArgs} args - Arguments to find a Productos
     * @example
     * // Get one Productos
     * const productos = await prisma.productos.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends productosFindUniqueArgs>(args: SelectSubset<T, productosFindUniqueArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Productos that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {productosFindUniqueOrThrowArgs} args - Arguments to find a Productos
     * @example
     * // Get one Productos
     * const productos = await prisma.productos.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends productosFindUniqueOrThrowArgs>(args: SelectSubset<T, productosFindUniqueOrThrowArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Productos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productosFindFirstArgs} args - Arguments to find a Productos
     * @example
     * // Get one Productos
     * const productos = await prisma.productos.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends productosFindFirstArgs>(args?: SelectSubset<T, productosFindFirstArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Productos that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productosFindFirstOrThrowArgs} args - Arguments to find a Productos
     * @example
     * // Get one Productos
     * const productos = await prisma.productos.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends productosFindFirstOrThrowArgs>(args?: SelectSubset<T, productosFindFirstOrThrowArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Productos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productosFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Productos
     * const productos = await prisma.productos.findMany()
     * 
     * // Get first 10 Productos
     * const productos = await prisma.productos.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const productosWithIdOnly = await prisma.productos.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends productosFindManyArgs>(args?: SelectSubset<T, productosFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Productos.
     * @param {productosCreateArgs} args - Arguments to create a Productos.
     * @example
     * // Create one Productos
     * const Productos = await prisma.productos.create({
     *   data: {
     *     // ... data to create a Productos
     *   }
     * })
     * 
     */
    create<T extends productosCreateArgs>(args: SelectSubset<T, productosCreateArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Productos.
     * @param {productosCreateManyArgs} args - Arguments to create many Productos.
     * @example
     * // Create many Productos
     * const productos = await prisma.productos.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends productosCreateManyArgs>(args?: SelectSubset<T, productosCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Productos and returns the data saved in the database.
     * @param {productosCreateManyAndReturnArgs} args - Arguments to create many Productos.
     * @example
     * // Create many Productos
     * const productos = await prisma.productos.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Productos and only return the `id`
     * const productosWithIdOnly = await prisma.productos.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends productosCreateManyAndReturnArgs>(args?: SelectSubset<T, productosCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Productos.
     * @param {productosDeleteArgs} args - Arguments to delete one Productos.
     * @example
     * // Delete one Productos
     * const Productos = await prisma.productos.delete({
     *   where: {
     *     // ... filter to delete one Productos
     *   }
     * })
     * 
     */
    delete<T extends productosDeleteArgs>(args: SelectSubset<T, productosDeleteArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Productos.
     * @param {productosUpdateArgs} args - Arguments to update one Productos.
     * @example
     * // Update one Productos
     * const productos = await prisma.productos.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends productosUpdateArgs>(args: SelectSubset<T, productosUpdateArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Productos.
     * @param {productosDeleteManyArgs} args - Arguments to filter Productos to delete.
     * @example
     * // Delete a few Productos
     * const { count } = await prisma.productos.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends productosDeleteManyArgs>(args?: SelectSubset<T, productosDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productosUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Productos
     * const productos = await prisma.productos.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends productosUpdateManyArgs>(args: SelectSubset<T, productosUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Productos and returns the data updated in the database.
     * @param {productosUpdateManyAndReturnArgs} args - Arguments to update many Productos.
     * @example
     * // Update many Productos
     * const productos = await prisma.productos.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Productos and only return the `id`
     * const productosWithIdOnly = await prisma.productos.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends productosUpdateManyAndReturnArgs>(args: SelectSubset<T, productosUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Productos.
     * @param {productosUpsertArgs} args - Arguments to update or create a Productos.
     * @example
     * // Update or create a Productos
     * const productos = await prisma.productos.upsert({
     *   create: {
     *     // ... data to create a Productos
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Productos we want to update
     *   }
     * })
     */
    upsert<T extends productosUpsertArgs>(args: SelectSubset<T, productosUpsertArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productosCountArgs} args - Arguments to filter Productos to count.
     * @example
     * // Count the number of Productos
     * const count = await prisma.productos.count({
     *   where: {
     *     // ... the filter for the Productos we want to count
     *   }
     * })
    **/
    count<T extends productosCountArgs>(
      args?: Subset<T, productosCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProductosCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductosAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProductosAggregateArgs>(args: Subset<T, ProductosAggregateArgs>): Prisma.PrismaPromise<GetProductosAggregateType<T>>

    /**
     * Group by Productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {productosGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends productosGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: productosGroupByArgs['orderBy'] }
        : { orderBy?: productosGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, productosGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProductosGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the productos model
   */
  readonly fields: productosFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for productos.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__productosClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    ordenesProductos<T extends productos$ordenesProductosArgs<ExtArgs> = {}>(args?: Subset<T, productos$ordenesProductosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the productos model
   */
  interface productosFieldRefs {
    readonly id: FieldRef<"productos", 'Int'>
    readonly nombre: FieldRef<"productos", 'String'>
    readonly descripcion: FieldRef<"productos", 'String'>
    readonly categoria: FieldRef<"productos", 'String'>
    readonly stock: FieldRef<"productos", 'Int'>
    readonly precio: FieldRef<"productos", 'Decimal'>
    readonly createdAt: FieldRef<"productos", 'DateTime'>
    readonly updatedAt: FieldRef<"productos", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * productos findUnique
   */
  export type productosFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * Filter, which productos to fetch.
     */
    where: productosWhereUniqueInput
  }

  /**
   * productos findUniqueOrThrow
   */
  export type productosFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * Filter, which productos to fetch.
     */
    where: productosWhereUniqueInput
  }

  /**
   * productos findFirst
   */
  export type productosFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * Filter, which productos to fetch.
     */
    where?: productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of productos to fetch.
     */
    orderBy?: productosOrderByWithRelationInput | productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for productos.
     */
    cursor?: productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of productos.
     */
    distinct?: ProductosScalarFieldEnum | ProductosScalarFieldEnum[]
  }

  /**
   * productos findFirstOrThrow
   */
  export type productosFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * Filter, which productos to fetch.
     */
    where?: productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of productos to fetch.
     */
    orderBy?: productosOrderByWithRelationInput | productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for productos.
     */
    cursor?: productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of productos.
     */
    distinct?: ProductosScalarFieldEnum | ProductosScalarFieldEnum[]
  }

  /**
   * productos findMany
   */
  export type productosFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * Filter, which productos to fetch.
     */
    where?: productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of productos to fetch.
     */
    orderBy?: productosOrderByWithRelationInput | productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing productos.
     */
    cursor?: productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of productos.
     */
    distinct?: ProductosScalarFieldEnum | ProductosScalarFieldEnum[]
  }

  /**
   * productos create
   */
  export type productosCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * The data needed to create a productos.
     */
    data: XOR<productosCreateInput, productosUncheckedCreateInput>
  }

  /**
   * productos createMany
   */
  export type productosCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many productos.
     */
    data: productosCreateManyInput | productosCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * productos createManyAndReturn
   */
  export type productosCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * The data used to create many productos.
     */
    data: productosCreateManyInput | productosCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * productos update
   */
  export type productosUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * The data needed to update a productos.
     */
    data: XOR<productosUpdateInput, productosUncheckedUpdateInput>
    /**
     * Choose, which productos to update.
     */
    where: productosWhereUniqueInput
  }

  /**
   * productos updateMany
   */
  export type productosUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update productos.
     */
    data: XOR<productosUpdateManyMutationInput, productosUncheckedUpdateManyInput>
    /**
     * Filter which productos to update
     */
    where?: productosWhereInput
    /**
     * Limit how many productos to update.
     */
    limit?: number
  }

  /**
   * productos updateManyAndReturn
   */
  export type productosUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * The data used to update productos.
     */
    data: XOR<productosUpdateManyMutationInput, productosUncheckedUpdateManyInput>
    /**
     * Filter which productos to update
     */
    where?: productosWhereInput
    /**
     * Limit how many productos to update.
     */
    limit?: number
  }

  /**
   * productos upsert
   */
  export type productosUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * The filter to search for the productos to update in case it exists.
     */
    where: productosWhereUniqueInput
    /**
     * In case the productos found by the `where` argument doesn't exist, create a new productos with this data.
     */
    create: XOR<productosCreateInput, productosUncheckedCreateInput>
    /**
     * In case the productos was found with the provided `where` argument, update it with this data.
     */
    update: XOR<productosUpdateInput, productosUncheckedUpdateInput>
  }

  /**
   * productos delete
   */
  export type productosDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
    /**
     * Filter which productos to delete.
     */
    where: productosWhereUniqueInput
  }

  /**
   * productos deleteMany
   */
  export type productosDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which productos to delete
     */
    where?: productosWhereInput
    /**
     * Limit how many productos to delete.
     */
    limit?: number
  }

  /**
   * productos.ordenesProductos
   */
  export type productos$ordenesProductosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    where?: ordenes_productosWhereInput
    orderBy?: ordenes_productosOrderByWithRelationInput | ordenes_productosOrderByWithRelationInput[]
    cursor?: ordenes_productosWhereUniqueInput
    take?: number
    skip?: number
    distinct?: Ordenes_productosScalarFieldEnum | Ordenes_productosScalarFieldEnum[]
  }

  /**
   * productos without action
   */
  export type productosDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the productos
     */
    select?: productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the productos
     */
    omit?: productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: productosInclude<ExtArgs> | null
  }


  /**
   * Model ordenes_productos
   */

  export type AggregateOrdenes_productos = {
    _count: Ordenes_productosCountAggregateOutputType | null
    _avg: Ordenes_productosAvgAggregateOutputType | null
    _sum: Ordenes_productosSumAggregateOutputType | null
    _min: Ordenes_productosMinAggregateOutputType | null
    _max: Ordenes_productosMaxAggregateOutputType | null
  }

  export type Ordenes_productosAvgAggregateOutputType = {
    id: number | null
    ordenId: number | null
    productId: number | null
    precioUnitario: Decimal | null
    cantidad: number | null
  }

  export type Ordenes_productosSumAggregateOutputType = {
    id: number | null
    ordenId: number | null
    productId: number | null
    precioUnitario: Decimal | null
    cantidad: number | null
  }

  export type Ordenes_productosMinAggregateOutputType = {
    id: number | null
    ordenId: number | null
    productId: number | null
    precioUnitario: Decimal | null
    cantidad: number | null
  }

  export type Ordenes_productosMaxAggregateOutputType = {
    id: number | null
    ordenId: number | null
    productId: number | null
    precioUnitario: Decimal | null
    cantidad: number | null
  }

  export type Ordenes_productosCountAggregateOutputType = {
    id: number
    ordenId: number
    productId: number
    precioUnitario: number
    cantidad: number
    _all: number
  }


  export type Ordenes_productosAvgAggregateInputType = {
    id?: true
    ordenId?: true
    productId?: true
    precioUnitario?: true
    cantidad?: true
  }

  export type Ordenes_productosSumAggregateInputType = {
    id?: true
    ordenId?: true
    productId?: true
    precioUnitario?: true
    cantidad?: true
  }

  export type Ordenes_productosMinAggregateInputType = {
    id?: true
    ordenId?: true
    productId?: true
    precioUnitario?: true
    cantidad?: true
  }

  export type Ordenes_productosMaxAggregateInputType = {
    id?: true
    ordenId?: true
    productId?: true
    precioUnitario?: true
    cantidad?: true
  }

  export type Ordenes_productosCountAggregateInputType = {
    id?: true
    ordenId?: true
    productId?: true
    precioUnitario?: true
    cantidad?: true
    _all?: true
  }

  export type Ordenes_productosAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ordenes_productos to aggregate.
     */
    where?: ordenes_productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes_productos to fetch.
     */
    orderBy?: ordenes_productosOrderByWithRelationInput | ordenes_productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ordenes_productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes_productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes_productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ordenes_productos
    **/
    _count?: true | Ordenes_productosCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Ordenes_productosAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Ordenes_productosSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Ordenes_productosMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Ordenes_productosMaxAggregateInputType
  }

  export type GetOrdenes_productosAggregateType<T extends Ordenes_productosAggregateArgs> = {
        [P in keyof T & keyof AggregateOrdenes_productos]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOrdenes_productos[P]>
      : GetScalarType<T[P], AggregateOrdenes_productos[P]>
  }




  export type ordenes_productosGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ordenes_productosWhereInput
    orderBy?: ordenes_productosOrderByWithAggregationInput | ordenes_productosOrderByWithAggregationInput[]
    by: Ordenes_productosScalarFieldEnum[] | Ordenes_productosScalarFieldEnum
    having?: ordenes_productosScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Ordenes_productosCountAggregateInputType | true
    _avg?: Ordenes_productosAvgAggregateInputType
    _sum?: Ordenes_productosSumAggregateInputType
    _min?: Ordenes_productosMinAggregateInputType
    _max?: Ordenes_productosMaxAggregateInputType
  }

  export type Ordenes_productosGroupByOutputType = {
    id: number
    ordenId: number
    productId: number
    precioUnitario: Decimal
    cantidad: number
    _count: Ordenes_productosCountAggregateOutputType | null
    _avg: Ordenes_productosAvgAggregateOutputType | null
    _sum: Ordenes_productosSumAggregateOutputType | null
    _min: Ordenes_productosMinAggregateOutputType | null
    _max: Ordenes_productosMaxAggregateOutputType | null
  }

  type GetOrdenes_productosGroupByPayload<T extends ordenes_productosGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Ordenes_productosGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Ordenes_productosGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Ordenes_productosGroupByOutputType[P]>
            : GetScalarType<T[P], Ordenes_productosGroupByOutputType[P]>
        }
      >
    >


  export type ordenes_productosSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ordenId?: boolean
    productId?: boolean
    precioUnitario?: boolean
    cantidad?: boolean
    orden?: boolean | ordenesDefaultArgs<ExtArgs>
    productos?: boolean | productosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ordenes_productos"]>

  export type ordenes_productosSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ordenId?: boolean
    productId?: boolean
    precioUnitario?: boolean
    cantidad?: boolean
    orden?: boolean | ordenesDefaultArgs<ExtArgs>
    productos?: boolean | productosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ordenes_productos"]>

  export type ordenes_productosSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    ordenId?: boolean
    productId?: boolean
    precioUnitario?: boolean
    cantidad?: boolean
    orden?: boolean | ordenesDefaultArgs<ExtArgs>
    productos?: boolean | productosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["ordenes_productos"]>

  export type ordenes_productosSelectScalar = {
    id?: boolean
    ordenId?: boolean
    productId?: boolean
    precioUnitario?: boolean
    cantidad?: boolean
  }

  export type ordenes_productosOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "ordenId" | "productId" | "precioUnitario" | "cantidad", ExtArgs["result"]["ordenes_productos"]>
  export type ordenes_productosInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    orden?: boolean | ordenesDefaultArgs<ExtArgs>
    productos?: boolean | productosDefaultArgs<ExtArgs>
  }
  export type ordenes_productosIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    orden?: boolean | ordenesDefaultArgs<ExtArgs>
    productos?: boolean | productosDefaultArgs<ExtArgs>
  }
  export type ordenes_productosIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    orden?: boolean | ordenesDefaultArgs<ExtArgs>
    productos?: boolean | productosDefaultArgs<ExtArgs>
  }

  export type $ordenes_productosPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ordenes_productos"
    objects: {
      orden: Prisma.$ordenesPayload<ExtArgs>
      productos: Prisma.$productosPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      ordenId: number
      productId: number
      precioUnitario: Prisma.Decimal
      cantidad: number
    }, ExtArgs["result"]["ordenes_productos"]>
    composites: {}
  }

  type ordenes_productosGetPayload<S extends boolean | null | undefined | ordenes_productosDefaultArgs> = $Result.GetResult<Prisma.$ordenes_productosPayload, S>

  type ordenes_productosCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ordenes_productosFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Ordenes_productosCountAggregateInputType | true
    }

  export interface ordenes_productosDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ordenes_productos'], meta: { name: 'ordenes_productos' } }
    /**
     * Find zero or one Ordenes_productos that matches the filter.
     * @param {ordenes_productosFindUniqueArgs} args - Arguments to find a Ordenes_productos
     * @example
     * // Get one Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ordenes_productosFindUniqueArgs>(args: SelectSubset<T, ordenes_productosFindUniqueArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Ordenes_productos that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ordenes_productosFindUniqueOrThrowArgs} args - Arguments to find a Ordenes_productos
     * @example
     * // Get one Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ordenes_productosFindUniqueOrThrowArgs>(args: SelectSubset<T, ordenes_productosFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Ordenes_productos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenes_productosFindFirstArgs} args - Arguments to find a Ordenes_productos
     * @example
     * // Get one Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ordenes_productosFindFirstArgs>(args?: SelectSubset<T, ordenes_productosFindFirstArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Ordenes_productos that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenes_productosFindFirstOrThrowArgs} args - Arguments to find a Ordenes_productos
     * @example
     * // Get one Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ordenes_productosFindFirstOrThrowArgs>(args?: SelectSubset<T, ordenes_productosFindFirstOrThrowArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Ordenes_productos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenes_productosFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.findMany()
     * 
     * // Get first 10 Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const ordenes_productosWithIdOnly = await prisma.ordenes_productos.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ordenes_productosFindManyArgs>(args?: SelectSubset<T, ordenes_productosFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Ordenes_productos.
     * @param {ordenes_productosCreateArgs} args - Arguments to create a Ordenes_productos.
     * @example
     * // Create one Ordenes_productos
     * const Ordenes_productos = await prisma.ordenes_productos.create({
     *   data: {
     *     // ... data to create a Ordenes_productos
     *   }
     * })
     * 
     */
    create<T extends ordenes_productosCreateArgs>(args: SelectSubset<T, ordenes_productosCreateArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Ordenes_productos.
     * @param {ordenes_productosCreateManyArgs} args - Arguments to create many Ordenes_productos.
     * @example
     * // Create many Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ordenes_productosCreateManyArgs>(args?: SelectSubset<T, ordenes_productosCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Ordenes_productos and returns the data saved in the database.
     * @param {ordenes_productosCreateManyAndReturnArgs} args - Arguments to create many Ordenes_productos.
     * @example
     * // Create many Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Ordenes_productos and only return the `id`
     * const ordenes_productosWithIdOnly = await prisma.ordenes_productos.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ordenes_productosCreateManyAndReturnArgs>(args?: SelectSubset<T, ordenes_productosCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Ordenes_productos.
     * @param {ordenes_productosDeleteArgs} args - Arguments to delete one Ordenes_productos.
     * @example
     * // Delete one Ordenes_productos
     * const Ordenes_productos = await prisma.ordenes_productos.delete({
     *   where: {
     *     // ... filter to delete one Ordenes_productos
     *   }
     * })
     * 
     */
    delete<T extends ordenes_productosDeleteArgs>(args: SelectSubset<T, ordenes_productosDeleteArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Ordenes_productos.
     * @param {ordenes_productosUpdateArgs} args - Arguments to update one Ordenes_productos.
     * @example
     * // Update one Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ordenes_productosUpdateArgs>(args: SelectSubset<T, ordenes_productosUpdateArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Ordenes_productos.
     * @param {ordenes_productosDeleteManyArgs} args - Arguments to filter Ordenes_productos to delete.
     * @example
     * // Delete a few Ordenes_productos
     * const { count } = await prisma.ordenes_productos.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ordenes_productosDeleteManyArgs>(args?: SelectSubset<T, ordenes_productosDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Ordenes_productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenes_productosUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ordenes_productosUpdateManyArgs>(args: SelectSubset<T, ordenes_productosUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Ordenes_productos and returns the data updated in the database.
     * @param {ordenes_productosUpdateManyAndReturnArgs} args - Arguments to update many Ordenes_productos.
     * @example
     * // Update many Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Ordenes_productos and only return the `id`
     * const ordenes_productosWithIdOnly = await prisma.ordenes_productos.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ordenes_productosUpdateManyAndReturnArgs>(args: SelectSubset<T, ordenes_productosUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Ordenes_productos.
     * @param {ordenes_productosUpsertArgs} args - Arguments to update or create a Ordenes_productos.
     * @example
     * // Update or create a Ordenes_productos
     * const ordenes_productos = await prisma.ordenes_productos.upsert({
     *   create: {
     *     // ... data to create a Ordenes_productos
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Ordenes_productos we want to update
     *   }
     * })
     */
    upsert<T extends ordenes_productosUpsertArgs>(args: SelectSubset<T, ordenes_productosUpsertArgs<ExtArgs>>): Prisma__ordenes_productosClient<$Result.GetResult<Prisma.$ordenes_productosPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Ordenes_productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenes_productosCountArgs} args - Arguments to filter Ordenes_productos to count.
     * @example
     * // Count the number of Ordenes_productos
     * const count = await prisma.ordenes_productos.count({
     *   where: {
     *     // ... the filter for the Ordenes_productos we want to count
     *   }
     * })
    **/
    count<T extends ordenes_productosCountArgs>(
      args?: Subset<T, ordenes_productosCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Ordenes_productosCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Ordenes_productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Ordenes_productosAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Ordenes_productosAggregateArgs>(args: Subset<T, Ordenes_productosAggregateArgs>): Prisma.PrismaPromise<GetOrdenes_productosAggregateType<T>>

    /**
     * Group by Ordenes_productos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ordenes_productosGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ordenes_productosGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ordenes_productosGroupByArgs['orderBy'] }
        : { orderBy?: ordenes_productosGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ordenes_productosGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOrdenes_productosGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ordenes_productos model
   */
  readonly fields: ordenes_productosFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ordenes_productos.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ordenes_productosClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    orden<T extends ordenesDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ordenesDefaultArgs<ExtArgs>>): Prisma__ordenesClient<$Result.GetResult<Prisma.$ordenesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    productos<T extends productosDefaultArgs<ExtArgs> = {}>(args?: Subset<T, productosDefaultArgs<ExtArgs>>): Prisma__productosClient<$Result.GetResult<Prisma.$productosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ordenes_productos model
   */
  interface ordenes_productosFieldRefs {
    readonly id: FieldRef<"ordenes_productos", 'Int'>
    readonly ordenId: FieldRef<"ordenes_productos", 'Int'>
    readonly productId: FieldRef<"ordenes_productos", 'Int'>
    readonly precioUnitario: FieldRef<"ordenes_productos", 'Decimal'>
    readonly cantidad: FieldRef<"ordenes_productos", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * ordenes_productos findUnique
   */
  export type ordenes_productosFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * Filter, which ordenes_productos to fetch.
     */
    where: ordenes_productosWhereUniqueInput
  }

  /**
   * ordenes_productos findUniqueOrThrow
   */
  export type ordenes_productosFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * Filter, which ordenes_productos to fetch.
     */
    where: ordenes_productosWhereUniqueInput
  }

  /**
   * ordenes_productos findFirst
   */
  export type ordenes_productosFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * Filter, which ordenes_productos to fetch.
     */
    where?: ordenes_productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes_productos to fetch.
     */
    orderBy?: ordenes_productosOrderByWithRelationInput | ordenes_productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ordenes_productos.
     */
    cursor?: ordenes_productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes_productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes_productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ordenes_productos.
     */
    distinct?: Ordenes_productosScalarFieldEnum | Ordenes_productosScalarFieldEnum[]
  }

  /**
   * ordenes_productos findFirstOrThrow
   */
  export type ordenes_productosFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * Filter, which ordenes_productos to fetch.
     */
    where?: ordenes_productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes_productos to fetch.
     */
    orderBy?: ordenes_productosOrderByWithRelationInput | ordenes_productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ordenes_productos.
     */
    cursor?: ordenes_productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes_productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes_productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ordenes_productos.
     */
    distinct?: Ordenes_productosScalarFieldEnum | Ordenes_productosScalarFieldEnum[]
  }

  /**
   * ordenes_productos findMany
   */
  export type ordenes_productosFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * Filter, which ordenes_productos to fetch.
     */
    where?: ordenes_productosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ordenes_productos to fetch.
     */
    orderBy?: ordenes_productosOrderByWithRelationInput | ordenes_productosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ordenes_productos.
     */
    cursor?: ordenes_productosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ordenes_productos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ordenes_productos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ordenes_productos.
     */
    distinct?: Ordenes_productosScalarFieldEnum | Ordenes_productosScalarFieldEnum[]
  }

  /**
   * ordenes_productos create
   */
  export type ordenes_productosCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * The data needed to create a ordenes_productos.
     */
    data: XOR<ordenes_productosCreateInput, ordenes_productosUncheckedCreateInput>
  }

  /**
   * ordenes_productos createMany
   */
  export type ordenes_productosCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ordenes_productos.
     */
    data: ordenes_productosCreateManyInput | ordenes_productosCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ordenes_productos createManyAndReturn
   */
  export type ordenes_productosCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * The data used to create many ordenes_productos.
     */
    data: ordenes_productosCreateManyInput | ordenes_productosCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ordenes_productos update
   */
  export type ordenes_productosUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * The data needed to update a ordenes_productos.
     */
    data: XOR<ordenes_productosUpdateInput, ordenes_productosUncheckedUpdateInput>
    /**
     * Choose, which ordenes_productos to update.
     */
    where: ordenes_productosWhereUniqueInput
  }

  /**
   * ordenes_productos updateMany
   */
  export type ordenes_productosUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ordenes_productos.
     */
    data: XOR<ordenes_productosUpdateManyMutationInput, ordenes_productosUncheckedUpdateManyInput>
    /**
     * Filter which ordenes_productos to update
     */
    where?: ordenes_productosWhereInput
    /**
     * Limit how many ordenes_productos to update.
     */
    limit?: number
  }

  /**
   * ordenes_productos updateManyAndReturn
   */
  export type ordenes_productosUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * The data used to update ordenes_productos.
     */
    data: XOR<ordenes_productosUpdateManyMutationInput, ordenes_productosUncheckedUpdateManyInput>
    /**
     * Filter which ordenes_productos to update
     */
    where?: ordenes_productosWhereInput
    /**
     * Limit how many ordenes_productos to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ordenes_productos upsert
   */
  export type ordenes_productosUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * The filter to search for the ordenes_productos to update in case it exists.
     */
    where: ordenes_productosWhereUniqueInput
    /**
     * In case the ordenes_productos found by the `where` argument doesn't exist, create a new ordenes_productos with this data.
     */
    create: XOR<ordenes_productosCreateInput, ordenes_productosUncheckedCreateInput>
    /**
     * In case the ordenes_productos was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ordenes_productosUpdateInput, ordenes_productosUncheckedUpdateInput>
  }

  /**
   * ordenes_productos delete
   */
  export type ordenes_productosDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
    /**
     * Filter which ordenes_productos to delete.
     */
    where: ordenes_productosWhereUniqueInput
  }

  /**
   * ordenes_productos deleteMany
   */
  export type ordenes_productosDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ordenes_productos to delete
     */
    where?: ordenes_productosWhereInput
    /**
     * Limit how many ordenes_productos to delete.
     */
    limit?: number
  }

  /**
   * ordenes_productos without action
   */
  export type ordenes_productosDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ordenes_productos
     */
    select?: ordenes_productosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ordenes_productos
     */
    omit?: ordenes_productosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ordenes_productosInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const OrdenesScalarFieldEnum: {
    id: 'id',
    usuarioId: 'usuarioId',
    fecha: 'fecha',
    estado: 'estado',
    createdAt: 'createdAt'
  };

  export type OrdenesScalarFieldEnum = (typeof OrdenesScalarFieldEnum)[keyof typeof OrdenesScalarFieldEnum]


  export const UsuariosScalarFieldEnum: {
    id: 'id',
    nombre: 'nombre',
    email: 'email',
    rol: 'rol',
    password: 'password',
    refreshToken: 'refreshToken',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UsuariosScalarFieldEnum = (typeof UsuariosScalarFieldEnum)[keyof typeof UsuariosScalarFieldEnum]


  export const ProductosScalarFieldEnum: {
    id: 'id',
    nombre: 'nombre',
    descripcion: 'descripcion',
    categoria: 'categoria',
    stock: 'stock',
    precio: 'precio',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type ProductosScalarFieldEnum = (typeof ProductosScalarFieldEnum)[keyof typeof ProductosScalarFieldEnum]


  export const Ordenes_productosScalarFieldEnum: {
    id: 'id',
    ordenId: 'ordenId',
    productId: 'productId',
    precioUnitario: 'precioUnitario',
    cantidad: 'cantidad'
  };

  export type Ordenes_productosScalarFieldEnum = (typeof Ordenes_productosScalarFieldEnum)[keyof typeof Ordenes_productosScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Estados'
   */
  export type EnumEstadosFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Estados'>
    


  /**
   * Reference to a field of type 'Estados[]'
   */
  export type ListEnumEstadosFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Estados[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Roles'
   */
  export type EnumRolesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Roles'>
    


  /**
   * Reference to a field of type 'Roles[]'
   */
  export type ListEnumRolesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Roles[]'>
    


  /**
   * Reference to a field of type 'Decimal'
   */
  export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>
    


  /**
   * Reference to a field of type 'Decimal[]'
   */
  export type ListDecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type ordenesWhereInput = {
    AND?: ordenesWhereInput | ordenesWhereInput[]
    OR?: ordenesWhereInput[]
    NOT?: ordenesWhereInput | ordenesWhereInput[]
    id?: IntFilter<"ordenes"> | number
    usuarioId?: IntFilter<"ordenes"> | number
    fecha?: DateTimeFilter<"ordenes"> | Date | string
    estado?: EnumEstadosFilter<"ordenes"> | $Enums.Estados
    createdAt?: DateTimeFilter<"ordenes"> | Date | string
    usuarios?: XOR<UsuariosScalarRelationFilter, usuariosWhereInput>
    ordenesProductos?: Ordenes_productosListRelationFilter
  }

  export type ordenesOrderByWithRelationInput = {
    id?: SortOrder
    usuarioId?: SortOrder
    fecha?: SortOrder
    estado?: SortOrder
    createdAt?: SortOrder
    usuarios?: usuariosOrderByWithRelationInput
    ordenesProductos?: ordenes_productosOrderByRelationAggregateInput
  }

  export type ordenesWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: ordenesWhereInput | ordenesWhereInput[]
    OR?: ordenesWhereInput[]
    NOT?: ordenesWhereInput | ordenesWhereInput[]
    usuarioId?: IntFilter<"ordenes"> | number
    fecha?: DateTimeFilter<"ordenes"> | Date | string
    estado?: EnumEstadosFilter<"ordenes"> | $Enums.Estados
    createdAt?: DateTimeFilter<"ordenes"> | Date | string
    usuarios?: XOR<UsuariosScalarRelationFilter, usuariosWhereInput>
    ordenesProductos?: Ordenes_productosListRelationFilter
  }, "id">

  export type ordenesOrderByWithAggregationInput = {
    id?: SortOrder
    usuarioId?: SortOrder
    fecha?: SortOrder
    estado?: SortOrder
    createdAt?: SortOrder
    _count?: ordenesCountOrderByAggregateInput
    _avg?: ordenesAvgOrderByAggregateInput
    _max?: ordenesMaxOrderByAggregateInput
    _min?: ordenesMinOrderByAggregateInput
    _sum?: ordenesSumOrderByAggregateInput
  }

  export type ordenesScalarWhereWithAggregatesInput = {
    AND?: ordenesScalarWhereWithAggregatesInput | ordenesScalarWhereWithAggregatesInput[]
    OR?: ordenesScalarWhereWithAggregatesInput[]
    NOT?: ordenesScalarWhereWithAggregatesInput | ordenesScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"ordenes"> | number
    usuarioId?: IntWithAggregatesFilter<"ordenes"> | number
    fecha?: DateTimeWithAggregatesFilter<"ordenes"> | Date | string
    estado?: EnumEstadosWithAggregatesFilter<"ordenes"> | $Enums.Estados
    createdAt?: DateTimeWithAggregatesFilter<"ordenes"> | Date | string
  }

  export type usuariosWhereInput = {
    AND?: usuariosWhereInput | usuariosWhereInput[]
    OR?: usuariosWhereInput[]
    NOT?: usuariosWhereInput | usuariosWhereInput[]
    id?: IntFilter<"usuarios"> | number
    nombre?: StringFilter<"usuarios"> | string
    email?: StringFilter<"usuarios"> | string
    rol?: EnumRolesFilter<"usuarios"> | $Enums.Roles
    password?: StringFilter<"usuarios"> | string
    refreshToken?: StringNullableFilter<"usuarios"> | string | null
    createdAt?: DateTimeFilter<"usuarios"> | Date | string
    updatedAt?: DateTimeFilter<"usuarios"> | Date | string
    ordenes?: OrdenesListRelationFilter
  }

  export type usuariosOrderByWithRelationInput = {
    id?: SortOrder
    nombre?: SortOrder
    email?: SortOrder
    rol?: SortOrder
    password?: SortOrder
    refreshToken?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    ordenes?: ordenesOrderByRelationAggregateInput
  }

  export type usuariosWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    email?: string
    AND?: usuariosWhereInput | usuariosWhereInput[]
    OR?: usuariosWhereInput[]
    NOT?: usuariosWhereInput | usuariosWhereInput[]
    nombre?: StringFilter<"usuarios"> | string
    rol?: EnumRolesFilter<"usuarios"> | $Enums.Roles
    password?: StringFilter<"usuarios"> | string
    refreshToken?: StringNullableFilter<"usuarios"> | string | null
    createdAt?: DateTimeFilter<"usuarios"> | Date | string
    updatedAt?: DateTimeFilter<"usuarios"> | Date | string
    ordenes?: OrdenesListRelationFilter
  }, "id" | "email">

  export type usuariosOrderByWithAggregationInput = {
    id?: SortOrder
    nombre?: SortOrder
    email?: SortOrder
    rol?: SortOrder
    password?: SortOrder
    refreshToken?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: usuariosCountOrderByAggregateInput
    _avg?: usuariosAvgOrderByAggregateInput
    _max?: usuariosMaxOrderByAggregateInput
    _min?: usuariosMinOrderByAggregateInput
    _sum?: usuariosSumOrderByAggregateInput
  }

  export type usuariosScalarWhereWithAggregatesInput = {
    AND?: usuariosScalarWhereWithAggregatesInput | usuariosScalarWhereWithAggregatesInput[]
    OR?: usuariosScalarWhereWithAggregatesInput[]
    NOT?: usuariosScalarWhereWithAggregatesInput | usuariosScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"usuarios"> | number
    nombre?: StringWithAggregatesFilter<"usuarios"> | string
    email?: StringWithAggregatesFilter<"usuarios"> | string
    rol?: EnumRolesWithAggregatesFilter<"usuarios"> | $Enums.Roles
    password?: StringWithAggregatesFilter<"usuarios"> | string
    refreshToken?: StringNullableWithAggregatesFilter<"usuarios"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"usuarios"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"usuarios"> | Date | string
  }

  export type productosWhereInput = {
    AND?: productosWhereInput | productosWhereInput[]
    OR?: productosWhereInput[]
    NOT?: productosWhereInput | productosWhereInput[]
    id?: IntFilter<"productos"> | number
    nombre?: StringFilter<"productos"> | string
    descripcion?: StringNullableFilter<"productos"> | string | null
    categoria?: StringFilter<"productos"> | string
    stock?: IntFilter<"productos"> | number
    precio?: DecimalFilter<"productos"> | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFilter<"productos"> | Date | string
    updatedAt?: DateTimeFilter<"productos"> | Date | string
    ordenesProductos?: Ordenes_productosListRelationFilter
  }

  export type productosOrderByWithRelationInput = {
    id?: SortOrder
    nombre?: SortOrder
    descripcion?: SortOrderInput | SortOrder
    categoria?: SortOrder
    stock?: SortOrder
    precio?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    ordenesProductos?: ordenes_productosOrderByRelationAggregateInput
  }

  export type productosWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: productosWhereInput | productosWhereInput[]
    OR?: productosWhereInput[]
    NOT?: productosWhereInput | productosWhereInput[]
    nombre?: StringFilter<"productos"> | string
    descripcion?: StringNullableFilter<"productos"> | string | null
    categoria?: StringFilter<"productos"> | string
    stock?: IntFilter<"productos"> | number
    precio?: DecimalFilter<"productos"> | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFilter<"productos"> | Date | string
    updatedAt?: DateTimeFilter<"productos"> | Date | string
    ordenesProductos?: Ordenes_productosListRelationFilter
  }, "id">

  export type productosOrderByWithAggregationInput = {
    id?: SortOrder
    nombre?: SortOrder
    descripcion?: SortOrderInput | SortOrder
    categoria?: SortOrder
    stock?: SortOrder
    precio?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: productosCountOrderByAggregateInput
    _avg?: productosAvgOrderByAggregateInput
    _max?: productosMaxOrderByAggregateInput
    _min?: productosMinOrderByAggregateInput
    _sum?: productosSumOrderByAggregateInput
  }

  export type productosScalarWhereWithAggregatesInput = {
    AND?: productosScalarWhereWithAggregatesInput | productosScalarWhereWithAggregatesInput[]
    OR?: productosScalarWhereWithAggregatesInput[]
    NOT?: productosScalarWhereWithAggregatesInput | productosScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"productos"> | number
    nombre?: StringWithAggregatesFilter<"productos"> | string
    descripcion?: StringNullableWithAggregatesFilter<"productos"> | string | null
    categoria?: StringWithAggregatesFilter<"productos"> | string
    stock?: IntWithAggregatesFilter<"productos"> | number
    precio?: DecimalWithAggregatesFilter<"productos"> | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeWithAggregatesFilter<"productos"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"productos"> | Date | string
  }

  export type ordenes_productosWhereInput = {
    AND?: ordenes_productosWhereInput | ordenes_productosWhereInput[]
    OR?: ordenes_productosWhereInput[]
    NOT?: ordenes_productosWhereInput | ordenes_productosWhereInput[]
    id?: IntFilter<"ordenes_productos"> | number
    ordenId?: IntFilter<"ordenes_productos"> | number
    productId?: IntFilter<"ordenes_productos"> | number
    precioUnitario?: DecimalFilter<"ordenes_productos"> | Decimal | DecimalJsLike | number | string
    cantidad?: IntFilter<"ordenes_productos"> | number
    orden?: XOR<OrdenesScalarRelationFilter, ordenesWhereInput>
    productos?: XOR<ProductosScalarRelationFilter, productosWhereInput>
  }

  export type ordenes_productosOrderByWithRelationInput = {
    id?: SortOrder
    ordenId?: SortOrder
    productId?: SortOrder
    precioUnitario?: SortOrder
    cantidad?: SortOrder
    orden?: ordenesOrderByWithRelationInput
    productos?: productosOrderByWithRelationInput
  }

  export type ordenes_productosWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: ordenes_productosWhereInput | ordenes_productosWhereInput[]
    OR?: ordenes_productosWhereInput[]
    NOT?: ordenes_productosWhereInput | ordenes_productosWhereInput[]
    ordenId?: IntFilter<"ordenes_productos"> | number
    productId?: IntFilter<"ordenes_productos"> | number
    precioUnitario?: DecimalFilter<"ordenes_productos"> | Decimal | DecimalJsLike | number | string
    cantidad?: IntFilter<"ordenes_productos"> | number
    orden?: XOR<OrdenesScalarRelationFilter, ordenesWhereInput>
    productos?: XOR<ProductosScalarRelationFilter, productosWhereInput>
  }, "id">

  export type ordenes_productosOrderByWithAggregationInput = {
    id?: SortOrder
    ordenId?: SortOrder
    productId?: SortOrder
    precioUnitario?: SortOrder
    cantidad?: SortOrder
    _count?: ordenes_productosCountOrderByAggregateInput
    _avg?: ordenes_productosAvgOrderByAggregateInput
    _max?: ordenes_productosMaxOrderByAggregateInput
    _min?: ordenes_productosMinOrderByAggregateInput
    _sum?: ordenes_productosSumOrderByAggregateInput
  }

  export type ordenes_productosScalarWhereWithAggregatesInput = {
    AND?: ordenes_productosScalarWhereWithAggregatesInput | ordenes_productosScalarWhereWithAggregatesInput[]
    OR?: ordenes_productosScalarWhereWithAggregatesInput[]
    NOT?: ordenes_productosScalarWhereWithAggregatesInput | ordenes_productosScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"ordenes_productos"> | number
    ordenId?: IntWithAggregatesFilter<"ordenes_productos"> | number
    productId?: IntWithAggregatesFilter<"ordenes_productos"> | number
    precioUnitario?: DecimalWithAggregatesFilter<"ordenes_productos"> | Decimal | DecimalJsLike | number | string
    cantidad?: IntWithAggregatesFilter<"ordenes_productos"> | number
  }

  export type ordenesCreateInput = {
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
    usuarios: usuariosCreateNestedOneWithoutOrdenesInput
    ordenesProductos?: ordenes_productosCreateNestedManyWithoutOrdenInput
  }

  export type ordenesUncheckedCreateInput = {
    id?: number
    usuarioId: number
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
    ordenesProductos?: ordenes_productosUncheckedCreateNestedManyWithoutOrdenInput
  }

  export type ordenesUpdateInput = {
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    usuarios?: usuariosUpdateOneRequiredWithoutOrdenesNestedInput
    ordenesProductos?: ordenes_productosUpdateManyWithoutOrdenNestedInput
  }

  export type ordenesUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    usuarioId?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    ordenesProductos?: ordenes_productosUncheckedUpdateManyWithoutOrdenNestedInput
  }

  export type ordenesCreateManyInput = {
    id?: number
    usuarioId: number
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
  }

  export type ordenesUpdateManyMutationInput = {
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ordenesUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    usuarioId?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type usuariosCreateInput = {
    nombre: string
    email: string
    rol?: $Enums.Roles
    password: string
    refreshToken?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    ordenes?: ordenesCreateNestedManyWithoutUsuariosInput
  }

  export type usuariosUncheckedCreateInput = {
    id?: number
    nombre: string
    email: string
    rol?: $Enums.Roles
    password: string
    refreshToken?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    ordenes?: ordenesUncheckedCreateNestedManyWithoutUsuariosInput
  }

  export type usuariosUpdateInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    rol?: EnumRolesFieldUpdateOperationsInput | $Enums.Roles
    password?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    ordenes?: ordenesUpdateManyWithoutUsuariosNestedInput
  }

  export type usuariosUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    rol?: EnumRolesFieldUpdateOperationsInput | $Enums.Roles
    password?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    ordenes?: ordenesUncheckedUpdateManyWithoutUsuariosNestedInput
  }

  export type usuariosCreateManyInput = {
    id?: number
    nombre: string
    email: string
    rol?: $Enums.Roles
    password: string
    refreshToken?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type usuariosUpdateManyMutationInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    rol?: EnumRolesFieldUpdateOperationsInput | $Enums.Roles
    password?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type usuariosUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    rol?: EnumRolesFieldUpdateOperationsInput | $Enums.Roles
    password?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type productosCreateInput = {
    nombre: string
    descripcion?: string | null
    categoria: string
    stock?: number
    precio?: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt?: Date | string
    ordenesProductos?: ordenes_productosCreateNestedManyWithoutProductosInput
  }

  export type productosUncheckedCreateInput = {
    id?: number
    nombre: string
    descripcion?: string | null
    categoria: string
    stock?: number
    precio?: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt?: Date | string
    ordenesProductos?: ordenes_productosUncheckedCreateNestedManyWithoutProductosInput
  }

  export type productosUpdateInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    descripcion?: NullableStringFieldUpdateOperationsInput | string | null
    categoria?: StringFieldUpdateOperationsInput | string
    stock?: IntFieldUpdateOperationsInput | number
    precio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    ordenesProductos?: ordenes_productosUpdateManyWithoutProductosNestedInput
  }

  export type productosUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    descripcion?: NullableStringFieldUpdateOperationsInput | string | null
    categoria?: StringFieldUpdateOperationsInput | string
    stock?: IntFieldUpdateOperationsInput | number
    precio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    ordenesProductos?: ordenes_productosUncheckedUpdateManyWithoutProductosNestedInput
  }

  export type productosCreateManyInput = {
    id?: number
    nombre: string
    descripcion?: string | null
    categoria: string
    stock?: number
    precio?: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type productosUpdateManyMutationInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    descripcion?: NullableStringFieldUpdateOperationsInput | string | null
    categoria?: StringFieldUpdateOperationsInput | string
    stock?: IntFieldUpdateOperationsInput | number
    precio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type productosUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    descripcion?: NullableStringFieldUpdateOperationsInput | string | null
    categoria?: StringFieldUpdateOperationsInput | string
    stock?: IntFieldUpdateOperationsInput | number
    precio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ordenes_productosCreateInput = {
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
    orden: ordenesCreateNestedOneWithoutOrdenesProductosInput
    productos: productosCreateNestedOneWithoutOrdenesProductosInput
  }

  export type ordenes_productosUncheckedCreateInput = {
    id?: number
    ordenId: number
    productId: number
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
  }

  export type ordenes_productosUpdateInput = {
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
    orden?: ordenesUpdateOneRequiredWithoutOrdenesProductosNestedInput
    productos?: productosUpdateOneRequiredWithoutOrdenesProductosNestedInput
  }

  export type ordenes_productosUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    ordenId?: IntFieldUpdateOperationsInput | number
    productId?: IntFieldUpdateOperationsInput | number
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
  }

  export type ordenes_productosCreateManyInput = {
    id?: number
    ordenId: number
    productId: number
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
  }

  export type ordenes_productosUpdateManyMutationInput = {
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
  }

  export type ordenes_productosUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    ordenId?: IntFieldUpdateOperationsInput | number
    productId?: IntFieldUpdateOperationsInput | number
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EnumEstadosFilter<$PrismaModel = never> = {
    equals?: $Enums.Estados | EnumEstadosFieldRefInput<$PrismaModel>
    in?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    notIn?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    not?: NestedEnumEstadosFilter<$PrismaModel> | $Enums.Estados
  }

  export type UsuariosScalarRelationFilter = {
    is?: usuariosWhereInput
    isNot?: usuariosWhereInput
  }

  export type Ordenes_productosListRelationFilter = {
    every?: ordenes_productosWhereInput
    some?: ordenes_productosWhereInput
    none?: ordenes_productosWhereInput
  }

  export type ordenes_productosOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ordenesCountOrderByAggregateInput = {
    id?: SortOrder
    usuarioId?: SortOrder
    fecha?: SortOrder
    estado?: SortOrder
    createdAt?: SortOrder
  }

  export type ordenesAvgOrderByAggregateInput = {
    id?: SortOrder
    usuarioId?: SortOrder
  }

  export type ordenesMaxOrderByAggregateInput = {
    id?: SortOrder
    usuarioId?: SortOrder
    fecha?: SortOrder
    estado?: SortOrder
    createdAt?: SortOrder
  }

  export type ordenesMinOrderByAggregateInput = {
    id?: SortOrder
    usuarioId?: SortOrder
    fecha?: SortOrder
    estado?: SortOrder
    createdAt?: SortOrder
  }

  export type ordenesSumOrderByAggregateInput = {
    id?: SortOrder
    usuarioId?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type EnumEstadosWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Estados | EnumEstadosFieldRefInput<$PrismaModel>
    in?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    notIn?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    not?: NestedEnumEstadosWithAggregatesFilter<$PrismaModel> | $Enums.Estados
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEstadosFilter<$PrismaModel>
    _max?: NestedEnumEstadosFilter<$PrismaModel>
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type EnumRolesFilter<$PrismaModel = never> = {
    equals?: $Enums.Roles | EnumRolesFieldRefInput<$PrismaModel>
    in?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    notIn?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    not?: NestedEnumRolesFilter<$PrismaModel> | $Enums.Roles
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type OrdenesListRelationFilter = {
    every?: ordenesWhereInput
    some?: ordenesWhereInput
    none?: ordenesWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type ordenesOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type usuariosCountOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    email?: SortOrder
    rol?: SortOrder
    password?: SortOrder
    refreshToken?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type usuariosAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type usuariosMaxOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    email?: SortOrder
    rol?: SortOrder
    password?: SortOrder
    refreshToken?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type usuariosMinOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    email?: SortOrder
    rol?: SortOrder
    password?: SortOrder
    refreshToken?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type usuariosSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type EnumRolesWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Roles | EnumRolesFieldRefInput<$PrismaModel>
    in?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    notIn?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    not?: NestedEnumRolesWithAggregatesFilter<$PrismaModel> | $Enums.Roles
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRolesFilter<$PrismaModel>
    _max?: NestedEnumRolesFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type productosCountOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    stock?: SortOrder
    precio?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type productosAvgOrderByAggregateInput = {
    id?: SortOrder
    stock?: SortOrder
    precio?: SortOrder
  }

  export type productosMaxOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    stock?: SortOrder
    precio?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type productosMinOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    stock?: SortOrder
    precio?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type productosSumOrderByAggregateInput = {
    id?: SortOrder
    stock?: SortOrder
    precio?: SortOrder
  }

  export type DecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type OrdenesScalarRelationFilter = {
    is?: ordenesWhereInput
    isNot?: ordenesWhereInput
  }

  export type ProductosScalarRelationFilter = {
    is?: productosWhereInput
    isNot?: productosWhereInput
  }

  export type ordenes_productosCountOrderByAggregateInput = {
    id?: SortOrder
    ordenId?: SortOrder
    productId?: SortOrder
    precioUnitario?: SortOrder
    cantidad?: SortOrder
  }

  export type ordenes_productosAvgOrderByAggregateInput = {
    id?: SortOrder
    ordenId?: SortOrder
    productId?: SortOrder
    precioUnitario?: SortOrder
    cantidad?: SortOrder
  }

  export type ordenes_productosMaxOrderByAggregateInput = {
    id?: SortOrder
    ordenId?: SortOrder
    productId?: SortOrder
    precioUnitario?: SortOrder
    cantidad?: SortOrder
  }

  export type ordenes_productosMinOrderByAggregateInput = {
    id?: SortOrder
    ordenId?: SortOrder
    productId?: SortOrder
    precioUnitario?: SortOrder
    cantidad?: SortOrder
  }

  export type ordenes_productosSumOrderByAggregateInput = {
    id?: SortOrder
    ordenId?: SortOrder
    productId?: SortOrder
    precioUnitario?: SortOrder
    cantidad?: SortOrder
  }

  export type usuariosCreateNestedOneWithoutOrdenesInput = {
    create?: XOR<usuariosCreateWithoutOrdenesInput, usuariosUncheckedCreateWithoutOrdenesInput>
    connectOrCreate?: usuariosCreateOrConnectWithoutOrdenesInput
    connect?: usuariosWhereUniqueInput
  }

  export type ordenes_productosCreateNestedManyWithoutOrdenInput = {
    create?: XOR<ordenes_productosCreateWithoutOrdenInput, ordenes_productosUncheckedCreateWithoutOrdenInput> | ordenes_productosCreateWithoutOrdenInput[] | ordenes_productosUncheckedCreateWithoutOrdenInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutOrdenInput | ordenes_productosCreateOrConnectWithoutOrdenInput[]
    createMany?: ordenes_productosCreateManyOrdenInputEnvelope
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
  }

  export type ordenes_productosUncheckedCreateNestedManyWithoutOrdenInput = {
    create?: XOR<ordenes_productosCreateWithoutOrdenInput, ordenes_productosUncheckedCreateWithoutOrdenInput> | ordenes_productosCreateWithoutOrdenInput[] | ordenes_productosUncheckedCreateWithoutOrdenInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutOrdenInput | ordenes_productosCreateOrConnectWithoutOrdenInput[]
    createMany?: ordenes_productosCreateManyOrdenInputEnvelope
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EnumEstadosFieldUpdateOperationsInput = {
    set?: $Enums.Estados
  }

  export type usuariosUpdateOneRequiredWithoutOrdenesNestedInput = {
    create?: XOR<usuariosCreateWithoutOrdenesInput, usuariosUncheckedCreateWithoutOrdenesInput>
    connectOrCreate?: usuariosCreateOrConnectWithoutOrdenesInput
    upsert?: usuariosUpsertWithoutOrdenesInput
    connect?: usuariosWhereUniqueInput
    update?: XOR<XOR<usuariosUpdateToOneWithWhereWithoutOrdenesInput, usuariosUpdateWithoutOrdenesInput>, usuariosUncheckedUpdateWithoutOrdenesInput>
  }

  export type ordenes_productosUpdateManyWithoutOrdenNestedInput = {
    create?: XOR<ordenes_productosCreateWithoutOrdenInput, ordenes_productosUncheckedCreateWithoutOrdenInput> | ordenes_productosCreateWithoutOrdenInput[] | ordenes_productosUncheckedCreateWithoutOrdenInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutOrdenInput | ordenes_productosCreateOrConnectWithoutOrdenInput[]
    upsert?: ordenes_productosUpsertWithWhereUniqueWithoutOrdenInput | ordenes_productosUpsertWithWhereUniqueWithoutOrdenInput[]
    createMany?: ordenes_productosCreateManyOrdenInputEnvelope
    set?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    disconnect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    delete?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    update?: ordenes_productosUpdateWithWhereUniqueWithoutOrdenInput | ordenes_productosUpdateWithWhereUniqueWithoutOrdenInput[]
    updateMany?: ordenes_productosUpdateManyWithWhereWithoutOrdenInput | ordenes_productosUpdateManyWithWhereWithoutOrdenInput[]
    deleteMany?: ordenes_productosScalarWhereInput | ordenes_productosScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type ordenes_productosUncheckedUpdateManyWithoutOrdenNestedInput = {
    create?: XOR<ordenes_productosCreateWithoutOrdenInput, ordenes_productosUncheckedCreateWithoutOrdenInput> | ordenes_productosCreateWithoutOrdenInput[] | ordenes_productosUncheckedCreateWithoutOrdenInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutOrdenInput | ordenes_productosCreateOrConnectWithoutOrdenInput[]
    upsert?: ordenes_productosUpsertWithWhereUniqueWithoutOrdenInput | ordenes_productosUpsertWithWhereUniqueWithoutOrdenInput[]
    createMany?: ordenes_productosCreateManyOrdenInputEnvelope
    set?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    disconnect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    delete?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    update?: ordenes_productosUpdateWithWhereUniqueWithoutOrdenInput | ordenes_productosUpdateWithWhereUniqueWithoutOrdenInput[]
    updateMany?: ordenes_productosUpdateManyWithWhereWithoutOrdenInput | ordenes_productosUpdateManyWithWhereWithoutOrdenInput[]
    deleteMany?: ordenes_productosScalarWhereInput | ordenes_productosScalarWhereInput[]
  }

  export type ordenesCreateNestedManyWithoutUsuariosInput = {
    create?: XOR<ordenesCreateWithoutUsuariosInput, ordenesUncheckedCreateWithoutUsuariosInput> | ordenesCreateWithoutUsuariosInput[] | ordenesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: ordenesCreateOrConnectWithoutUsuariosInput | ordenesCreateOrConnectWithoutUsuariosInput[]
    createMany?: ordenesCreateManyUsuariosInputEnvelope
    connect?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
  }

  export type ordenesUncheckedCreateNestedManyWithoutUsuariosInput = {
    create?: XOR<ordenesCreateWithoutUsuariosInput, ordenesUncheckedCreateWithoutUsuariosInput> | ordenesCreateWithoutUsuariosInput[] | ordenesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: ordenesCreateOrConnectWithoutUsuariosInput | ordenesCreateOrConnectWithoutUsuariosInput[]
    createMany?: ordenesCreateManyUsuariosInputEnvelope
    connect?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type EnumRolesFieldUpdateOperationsInput = {
    set?: $Enums.Roles
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type ordenesUpdateManyWithoutUsuariosNestedInput = {
    create?: XOR<ordenesCreateWithoutUsuariosInput, ordenesUncheckedCreateWithoutUsuariosInput> | ordenesCreateWithoutUsuariosInput[] | ordenesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: ordenesCreateOrConnectWithoutUsuariosInput | ordenesCreateOrConnectWithoutUsuariosInput[]
    upsert?: ordenesUpsertWithWhereUniqueWithoutUsuariosInput | ordenesUpsertWithWhereUniqueWithoutUsuariosInput[]
    createMany?: ordenesCreateManyUsuariosInputEnvelope
    set?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    disconnect?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    delete?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    connect?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    update?: ordenesUpdateWithWhereUniqueWithoutUsuariosInput | ordenesUpdateWithWhereUniqueWithoutUsuariosInput[]
    updateMany?: ordenesUpdateManyWithWhereWithoutUsuariosInput | ordenesUpdateManyWithWhereWithoutUsuariosInput[]
    deleteMany?: ordenesScalarWhereInput | ordenesScalarWhereInput[]
  }

  export type ordenesUncheckedUpdateManyWithoutUsuariosNestedInput = {
    create?: XOR<ordenesCreateWithoutUsuariosInput, ordenesUncheckedCreateWithoutUsuariosInput> | ordenesCreateWithoutUsuariosInput[] | ordenesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: ordenesCreateOrConnectWithoutUsuariosInput | ordenesCreateOrConnectWithoutUsuariosInput[]
    upsert?: ordenesUpsertWithWhereUniqueWithoutUsuariosInput | ordenesUpsertWithWhereUniqueWithoutUsuariosInput[]
    createMany?: ordenesCreateManyUsuariosInputEnvelope
    set?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    disconnect?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    delete?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    connect?: ordenesWhereUniqueInput | ordenesWhereUniqueInput[]
    update?: ordenesUpdateWithWhereUniqueWithoutUsuariosInput | ordenesUpdateWithWhereUniqueWithoutUsuariosInput[]
    updateMany?: ordenesUpdateManyWithWhereWithoutUsuariosInput | ordenesUpdateManyWithWhereWithoutUsuariosInput[]
    deleteMany?: ordenesScalarWhereInput | ordenesScalarWhereInput[]
  }

  export type ordenes_productosCreateNestedManyWithoutProductosInput = {
    create?: XOR<ordenes_productosCreateWithoutProductosInput, ordenes_productosUncheckedCreateWithoutProductosInput> | ordenes_productosCreateWithoutProductosInput[] | ordenes_productosUncheckedCreateWithoutProductosInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutProductosInput | ordenes_productosCreateOrConnectWithoutProductosInput[]
    createMany?: ordenes_productosCreateManyProductosInputEnvelope
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
  }

  export type ordenes_productosUncheckedCreateNestedManyWithoutProductosInput = {
    create?: XOR<ordenes_productosCreateWithoutProductosInput, ordenes_productosUncheckedCreateWithoutProductosInput> | ordenes_productosCreateWithoutProductosInput[] | ordenes_productosUncheckedCreateWithoutProductosInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutProductosInput | ordenes_productosCreateOrConnectWithoutProductosInput[]
    createMany?: ordenes_productosCreateManyProductosInputEnvelope
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
  }

  export type DecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type ordenes_productosUpdateManyWithoutProductosNestedInput = {
    create?: XOR<ordenes_productosCreateWithoutProductosInput, ordenes_productosUncheckedCreateWithoutProductosInput> | ordenes_productosCreateWithoutProductosInput[] | ordenes_productosUncheckedCreateWithoutProductosInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutProductosInput | ordenes_productosCreateOrConnectWithoutProductosInput[]
    upsert?: ordenes_productosUpsertWithWhereUniqueWithoutProductosInput | ordenes_productosUpsertWithWhereUniqueWithoutProductosInput[]
    createMany?: ordenes_productosCreateManyProductosInputEnvelope
    set?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    disconnect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    delete?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    update?: ordenes_productosUpdateWithWhereUniqueWithoutProductosInput | ordenes_productosUpdateWithWhereUniqueWithoutProductosInput[]
    updateMany?: ordenes_productosUpdateManyWithWhereWithoutProductosInput | ordenes_productosUpdateManyWithWhereWithoutProductosInput[]
    deleteMany?: ordenes_productosScalarWhereInput | ordenes_productosScalarWhereInput[]
  }

  export type ordenes_productosUncheckedUpdateManyWithoutProductosNestedInput = {
    create?: XOR<ordenes_productosCreateWithoutProductosInput, ordenes_productosUncheckedCreateWithoutProductosInput> | ordenes_productosCreateWithoutProductosInput[] | ordenes_productosUncheckedCreateWithoutProductosInput[]
    connectOrCreate?: ordenes_productosCreateOrConnectWithoutProductosInput | ordenes_productosCreateOrConnectWithoutProductosInput[]
    upsert?: ordenes_productosUpsertWithWhereUniqueWithoutProductosInput | ordenes_productosUpsertWithWhereUniqueWithoutProductosInput[]
    createMany?: ordenes_productosCreateManyProductosInputEnvelope
    set?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    disconnect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    delete?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    connect?: ordenes_productosWhereUniqueInput | ordenes_productosWhereUniqueInput[]
    update?: ordenes_productosUpdateWithWhereUniqueWithoutProductosInput | ordenes_productosUpdateWithWhereUniqueWithoutProductosInput[]
    updateMany?: ordenes_productosUpdateManyWithWhereWithoutProductosInput | ordenes_productosUpdateManyWithWhereWithoutProductosInput[]
    deleteMany?: ordenes_productosScalarWhereInput | ordenes_productosScalarWhereInput[]
  }

  export type ordenesCreateNestedOneWithoutOrdenesProductosInput = {
    create?: XOR<ordenesCreateWithoutOrdenesProductosInput, ordenesUncheckedCreateWithoutOrdenesProductosInput>
    connectOrCreate?: ordenesCreateOrConnectWithoutOrdenesProductosInput
    connect?: ordenesWhereUniqueInput
  }

  export type productosCreateNestedOneWithoutOrdenesProductosInput = {
    create?: XOR<productosCreateWithoutOrdenesProductosInput, productosUncheckedCreateWithoutOrdenesProductosInput>
    connectOrCreate?: productosCreateOrConnectWithoutOrdenesProductosInput
    connect?: productosWhereUniqueInput
  }

  export type ordenesUpdateOneRequiredWithoutOrdenesProductosNestedInput = {
    create?: XOR<ordenesCreateWithoutOrdenesProductosInput, ordenesUncheckedCreateWithoutOrdenesProductosInput>
    connectOrCreate?: ordenesCreateOrConnectWithoutOrdenesProductosInput
    upsert?: ordenesUpsertWithoutOrdenesProductosInput
    connect?: ordenesWhereUniqueInput
    update?: XOR<XOR<ordenesUpdateToOneWithWhereWithoutOrdenesProductosInput, ordenesUpdateWithoutOrdenesProductosInput>, ordenesUncheckedUpdateWithoutOrdenesProductosInput>
  }

  export type productosUpdateOneRequiredWithoutOrdenesProductosNestedInput = {
    create?: XOR<productosCreateWithoutOrdenesProductosInput, productosUncheckedCreateWithoutOrdenesProductosInput>
    connectOrCreate?: productosCreateOrConnectWithoutOrdenesProductosInput
    upsert?: productosUpsertWithoutOrdenesProductosInput
    connect?: productosWhereUniqueInput
    update?: XOR<XOR<productosUpdateToOneWithWhereWithoutOrdenesProductosInput, productosUpdateWithoutOrdenesProductosInput>, productosUncheckedUpdateWithoutOrdenesProductosInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedEnumEstadosFilter<$PrismaModel = never> = {
    equals?: $Enums.Estados | EnumEstadosFieldRefInput<$PrismaModel>
    in?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    notIn?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    not?: NestedEnumEstadosFilter<$PrismaModel> | $Enums.Estados
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedEnumEstadosWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Estados | EnumEstadosFieldRefInput<$PrismaModel>
    in?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    notIn?: $Enums.Estados[] | ListEnumEstadosFieldRefInput<$PrismaModel>
    not?: NestedEnumEstadosWithAggregatesFilter<$PrismaModel> | $Enums.Estados
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEstadosFilter<$PrismaModel>
    _max?: NestedEnumEstadosFilter<$PrismaModel>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedEnumRolesFilter<$PrismaModel = never> = {
    equals?: $Enums.Roles | EnumRolesFieldRefInput<$PrismaModel>
    in?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    notIn?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    not?: NestedEnumRolesFilter<$PrismaModel> | $Enums.Roles
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedEnumRolesWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Roles | EnumRolesFieldRefInput<$PrismaModel>
    in?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    notIn?: $Enums.Roles[] | ListEnumRolesFieldRefInput<$PrismaModel>
    not?: NestedEnumRolesWithAggregatesFilter<$PrismaModel> | $Enums.Roles
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRolesFilter<$PrismaModel>
    _max?: NestedEnumRolesFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type NestedDecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type usuariosCreateWithoutOrdenesInput = {
    nombre: string
    email: string
    rol?: $Enums.Roles
    password: string
    refreshToken?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type usuariosUncheckedCreateWithoutOrdenesInput = {
    id?: number
    nombre: string
    email: string
    rol?: $Enums.Roles
    password: string
    refreshToken?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type usuariosCreateOrConnectWithoutOrdenesInput = {
    where: usuariosWhereUniqueInput
    create: XOR<usuariosCreateWithoutOrdenesInput, usuariosUncheckedCreateWithoutOrdenesInput>
  }

  export type ordenes_productosCreateWithoutOrdenInput = {
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
    productos: productosCreateNestedOneWithoutOrdenesProductosInput
  }

  export type ordenes_productosUncheckedCreateWithoutOrdenInput = {
    id?: number
    productId: number
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
  }

  export type ordenes_productosCreateOrConnectWithoutOrdenInput = {
    where: ordenes_productosWhereUniqueInput
    create: XOR<ordenes_productosCreateWithoutOrdenInput, ordenes_productosUncheckedCreateWithoutOrdenInput>
  }

  export type ordenes_productosCreateManyOrdenInputEnvelope = {
    data: ordenes_productosCreateManyOrdenInput | ordenes_productosCreateManyOrdenInput[]
    skipDuplicates?: boolean
  }

  export type usuariosUpsertWithoutOrdenesInput = {
    update: XOR<usuariosUpdateWithoutOrdenesInput, usuariosUncheckedUpdateWithoutOrdenesInput>
    create: XOR<usuariosCreateWithoutOrdenesInput, usuariosUncheckedCreateWithoutOrdenesInput>
    where?: usuariosWhereInput
  }

  export type usuariosUpdateToOneWithWhereWithoutOrdenesInput = {
    where?: usuariosWhereInput
    data: XOR<usuariosUpdateWithoutOrdenesInput, usuariosUncheckedUpdateWithoutOrdenesInput>
  }

  export type usuariosUpdateWithoutOrdenesInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    rol?: EnumRolesFieldUpdateOperationsInput | $Enums.Roles
    password?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type usuariosUncheckedUpdateWithoutOrdenesInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    rol?: EnumRolesFieldUpdateOperationsInput | $Enums.Roles
    password?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ordenes_productosUpsertWithWhereUniqueWithoutOrdenInput = {
    where: ordenes_productosWhereUniqueInput
    update: XOR<ordenes_productosUpdateWithoutOrdenInput, ordenes_productosUncheckedUpdateWithoutOrdenInput>
    create: XOR<ordenes_productosCreateWithoutOrdenInput, ordenes_productosUncheckedCreateWithoutOrdenInput>
  }

  export type ordenes_productosUpdateWithWhereUniqueWithoutOrdenInput = {
    where: ordenes_productosWhereUniqueInput
    data: XOR<ordenes_productosUpdateWithoutOrdenInput, ordenes_productosUncheckedUpdateWithoutOrdenInput>
  }

  export type ordenes_productosUpdateManyWithWhereWithoutOrdenInput = {
    where: ordenes_productosScalarWhereInput
    data: XOR<ordenes_productosUpdateManyMutationInput, ordenes_productosUncheckedUpdateManyWithoutOrdenInput>
  }

  export type ordenes_productosScalarWhereInput = {
    AND?: ordenes_productosScalarWhereInput | ordenes_productosScalarWhereInput[]
    OR?: ordenes_productosScalarWhereInput[]
    NOT?: ordenes_productosScalarWhereInput | ordenes_productosScalarWhereInput[]
    id?: IntFilter<"ordenes_productos"> | number
    ordenId?: IntFilter<"ordenes_productos"> | number
    productId?: IntFilter<"ordenes_productos"> | number
    precioUnitario?: DecimalFilter<"ordenes_productos"> | Decimal | DecimalJsLike | number | string
    cantidad?: IntFilter<"ordenes_productos"> | number
  }

  export type ordenesCreateWithoutUsuariosInput = {
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
    ordenesProductos?: ordenes_productosCreateNestedManyWithoutOrdenInput
  }

  export type ordenesUncheckedCreateWithoutUsuariosInput = {
    id?: number
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
    ordenesProductos?: ordenes_productosUncheckedCreateNestedManyWithoutOrdenInput
  }

  export type ordenesCreateOrConnectWithoutUsuariosInput = {
    where: ordenesWhereUniqueInput
    create: XOR<ordenesCreateWithoutUsuariosInput, ordenesUncheckedCreateWithoutUsuariosInput>
  }

  export type ordenesCreateManyUsuariosInputEnvelope = {
    data: ordenesCreateManyUsuariosInput | ordenesCreateManyUsuariosInput[]
    skipDuplicates?: boolean
  }

  export type ordenesUpsertWithWhereUniqueWithoutUsuariosInput = {
    where: ordenesWhereUniqueInput
    update: XOR<ordenesUpdateWithoutUsuariosInput, ordenesUncheckedUpdateWithoutUsuariosInput>
    create: XOR<ordenesCreateWithoutUsuariosInput, ordenesUncheckedCreateWithoutUsuariosInput>
  }

  export type ordenesUpdateWithWhereUniqueWithoutUsuariosInput = {
    where: ordenesWhereUniqueInput
    data: XOR<ordenesUpdateWithoutUsuariosInput, ordenesUncheckedUpdateWithoutUsuariosInput>
  }

  export type ordenesUpdateManyWithWhereWithoutUsuariosInput = {
    where: ordenesScalarWhereInput
    data: XOR<ordenesUpdateManyMutationInput, ordenesUncheckedUpdateManyWithoutUsuariosInput>
  }

  export type ordenesScalarWhereInput = {
    AND?: ordenesScalarWhereInput | ordenesScalarWhereInput[]
    OR?: ordenesScalarWhereInput[]
    NOT?: ordenesScalarWhereInput | ordenesScalarWhereInput[]
    id?: IntFilter<"ordenes"> | number
    usuarioId?: IntFilter<"ordenes"> | number
    fecha?: DateTimeFilter<"ordenes"> | Date | string
    estado?: EnumEstadosFilter<"ordenes"> | $Enums.Estados
    createdAt?: DateTimeFilter<"ordenes"> | Date | string
  }

  export type ordenes_productosCreateWithoutProductosInput = {
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
    orden: ordenesCreateNestedOneWithoutOrdenesProductosInput
  }

  export type ordenes_productosUncheckedCreateWithoutProductosInput = {
    id?: number
    ordenId: number
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
  }

  export type ordenes_productosCreateOrConnectWithoutProductosInput = {
    where: ordenes_productosWhereUniqueInput
    create: XOR<ordenes_productosCreateWithoutProductosInput, ordenes_productosUncheckedCreateWithoutProductosInput>
  }

  export type ordenes_productosCreateManyProductosInputEnvelope = {
    data: ordenes_productosCreateManyProductosInput | ordenes_productosCreateManyProductosInput[]
    skipDuplicates?: boolean
  }

  export type ordenes_productosUpsertWithWhereUniqueWithoutProductosInput = {
    where: ordenes_productosWhereUniqueInput
    update: XOR<ordenes_productosUpdateWithoutProductosInput, ordenes_productosUncheckedUpdateWithoutProductosInput>
    create: XOR<ordenes_productosCreateWithoutProductosInput, ordenes_productosUncheckedCreateWithoutProductosInput>
  }

  export type ordenes_productosUpdateWithWhereUniqueWithoutProductosInput = {
    where: ordenes_productosWhereUniqueInput
    data: XOR<ordenes_productosUpdateWithoutProductosInput, ordenes_productosUncheckedUpdateWithoutProductosInput>
  }

  export type ordenes_productosUpdateManyWithWhereWithoutProductosInput = {
    where: ordenes_productosScalarWhereInput
    data: XOR<ordenes_productosUpdateManyMutationInput, ordenes_productosUncheckedUpdateManyWithoutProductosInput>
  }

  export type ordenesCreateWithoutOrdenesProductosInput = {
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
    usuarios: usuariosCreateNestedOneWithoutOrdenesInput
  }

  export type ordenesUncheckedCreateWithoutOrdenesProductosInput = {
    id?: number
    usuarioId: number
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
  }

  export type ordenesCreateOrConnectWithoutOrdenesProductosInput = {
    where: ordenesWhereUniqueInput
    create: XOR<ordenesCreateWithoutOrdenesProductosInput, ordenesUncheckedCreateWithoutOrdenesProductosInput>
  }

  export type productosCreateWithoutOrdenesProductosInput = {
    nombre: string
    descripcion?: string | null
    categoria: string
    stock?: number
    precio?: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type productosUncheckedCreateWithoutOrdenesProductosInput = {
    id?: number
    nombre: string
    descripcion?: string | null
    categoria: string
    stock?: number
    precio?: Decimal | DecimalJsLike | number | string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type productosCreateOrConnectWithoutOrdenesProductosInput = {
    where: productosWhereUniqueInput
    create: XOR<productosCreateWithoutOrdenesProductosInput, productosUncheckedCreateWithoutOrdenesProductosInput>
  }

  export type ordenesUpsertWithoutOrdenesProductosInput = {
    update: XOR<ordenesUpdateWithoutOrdenesProductosInput, ordenesUncheckedUpdateWithoutOrdenesProductosInput>
    create: XOR<ordenesCreateWithoutOrdenesProductosInput, ordenesUncheckedCreateWithoutOrdenesProductosInput>
    where?: ordenesWhereInput
  }

  export type ordenesUpdateToOneWithWhereWithoutOrdenesProductosInput = {
    where?: ordenesWhereInput
    data: XOR<ordenesUpdateWithoutOrdenesProductosInput, ordenesUncheckedUpdateWithoutOrdenesProductosInput>
  }

  export type ordenesUpdateWithoutOrdenesProductosInput = {
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    usuarios?: usuariosUpdateOneRequiredWithoutOrdenesNestedInput
  }

  export type ordenesUncheckedUpdateWithoutOrdenesProductosInput = {
    id?: IntFieldUpdateOperationsInput | number
    usuarioId?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type productosUpsertWithoutOrdenesProductosInput = {
    update: XOR<productosUpdateWithoutOrdenesProductosInput, productosUncheckedUpdateWithoutOrdenesProductosInput>
    create: XOR<productosCreateWithoutOrdenesProductosInput, productosUncheckedCreateWithoutOrdenesProductosInput>
    where?: productosWhereInput
  }

  export type productosUpdateToOneWithWhereWithoutOrdenesProductosInput = {
    where?: productosWhereInput
    data: XOR<productosUpdateWithoutOrdenesProductosInput, productosUncheckedUpdateWithoutOrdenesProductosInput>
  }

  export type productosUpdateWithoutOrdenesProductosInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    descripcion?: NullableStringFieldUpdateOperationsInput | string | null
    categoria?: StringFieldUpdateOperationsInput | string
    stock?: IntFieldUpdateOperationsInput | number
    precio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type productosUncheckedUpdateWithoutOrdenesProductosInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    descripcion?: NullableStringFieldUpdateOperationsInput | string | null
    categoria?: StringFieldUpdateOperationsInput | string
    stock?: IntFieldUpdateOperationsInput | number
    precio?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ordenes_productosCreateManyOrdenInput = {
    id?: number
    productId: number
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
  }

  export type ordenes_productosUpdateWithoutOrdenInput = {
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
    productos?: productosUpdateOneRequiredWithoutOrdenesProductosNestedInput
  }

  export type ordenes_productosUncheckedUpdateWithoutOrdenInput = {
    id?: IntFieldUpdateOperationsInput | number
    productId?: IntFieldUpdateOperationsInput | number
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
  }

  export type ordenes_productosUncheckedUpdateManyWithoutOrdenInput = {
    id?: IntFieldUpdateOperationsInput | number
    productId?: IntFieldUpdateOperationsInput | number
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
  }

  export type ordenesCreateManyUsuariosInput = {
    id?: number
    fecha?: Date | string
    estado?: $Enums.Estados
    createdAt?: Date | string
  }

  export type ordenesUpdateWithoutUsuariosInput = {
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    ordenesProductos?: ordenes_productosUpdateManyWithoutOrdenNestedInput
  }

  export type ordenesUncheckedUpdateWithoutUsuariosInput = {
    id?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    ordenesProductos?: ordenes_productosUncheckedUpdateManyWithoutOrdenNestedInput
  }

  export type ordenesUncheckedUpdateManyWithoutUsuariosInput = {
    id?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estado?: EnumEstadosFieldUpdateOperationsInput | $Enums.Estados
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ordenes_productosCreateManyProductosInput = {
    id?: number
    ordenId: number
    precioUnitario?: Decimal | DecimalJsLike | number | string
    cantidad?: number
  }

  export type ordenes_productosUpdateWithoutProductosInput = {
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
    orden?: ordenesUpdateOneRequiredWithoutOrdenesProductosNestedInput
  }

  export type ordenes_productosUncheckedUpdateWithoutProductosInput = {
    id?: IntFieldUpdateOperationsInput | number
    ordenId?: IntFieldUpdateOperationsInput | number
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
  }

  export type ordenes_productosUncheckedUpdateManyWithoutProductosInput = {
    id?: IntFieldUpdateOperationsInput | number
    ordenId?: IntFieldUpdateOperationsInput | number
    precioUnitario?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    cantidad?: IntFieldUpdateOperationsInput | number
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}